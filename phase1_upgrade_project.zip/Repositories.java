package com.sparehub.repository;

import com.sparehub.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

// CategoryRepository
interface CategoryRepository extends JpaRepository<Category, Long> {}

// ProductRepository
interface ProductRepository extends JpaRepository<Product, Long> {

    @Query("SELECT p FROM Product p WHERE LOWER(p.name) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "OR LOWER(p.description) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Product> searchByKeyword(@Param("keyword") String keyword);

    List<Product> findByCategoryId(Long categoryId);
}

// VendorRepository
interface VendorRepository extends JpaRepository<Vendor, Long> {

    @Query("SELECT v FROM Vendor v WHERE v.isActive = true")
    List<Vendor> findAllActive();
}

// VendorProductRepository
interface VendorProductRepository extends JpaRepository<VendorProduct, Long> {

    @Query("SELECT vp FROM VendorProduct vp WHERE vp.product.id = :productId AND vp.isAvailable = true AND vp.vendor.isActive = true")
    List<VendorProduct> findByProductId(@Param("productId") Long productId);

    @Query("SELECT vp FROM VendorProduct vp WHERE vp.vendor.id = :vendorId AND vp.isAvailable = true")
    List<VendorProduct> findByVendorId(@Param("vendorId") Long vendorId);

    @Query("""
        SELECT vp FROM VendorProduct vp
        WHERE vp.isAvailable = true
        AND vp.vendor.isActive = true
        AND vp.product.category.id = :categoryId
    """)
    List<VendorProduct> findByCategoryId(@Param("categoryId") Long categoryId);

    // Find all vendor products where product name/desc matches keyword
    @Query("""
        SELECT vp FROM VendorProduct vp
        WHERE vp.isAvailable = true
        AND vp.vendor.isActive = true
        AND (LOWER(vp.product.name) LIKE LOWER(CONCAT('%', :keyword, '%'))
             OR LOWER(vp.product.description) LIKE LOWER(CONCAT('%', :keyword, '%')))
    """)
    List<VendorProduct> searchByKeyword(@Param("keyword") String keyword);
}
