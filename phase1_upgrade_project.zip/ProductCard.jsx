import { Link } from 'react-router-dom'
import { useLocation } from '../context/LocationContext'
import { MapPin, Store, Tag } from 'lucide-react'

export default function ProductCard({ product }) {
  const { location } = useLocation()
  const params = location ? `?lat=${location.lat}&lng=${location.lng}` : ''

  return (
    <Link to={`/product/${product.id}${params}`} style={styles.card}>
      {/* Category badge */}
      <div style={styles.catBadge}>
        <span>{product.categoryIcon}</span>
        <span>{product.categoryName}</span>
      </div>

      {/* Product name */}
      <h3 style={styles.name}>{product.name}</h3>

      <p style={styles.desc}>
        {product.description?.length > 70
          ? product.description.slice(0, 70) + '…'
          : product.description}
      </p>

      {/* Footer row */}
      <div style={styles.footer}>
        <div>
          <div style={styles.priceLabel}>Starting from</div>
          <div style={styles.price}>₹{product.minPrice?.toLocaleString('en-IN')}</div>
          <div style={styles.unit}>per {product.unit}</div>
        </div>

        <div style={styles.metaCol}>
          <div style={styles.metaItem}>
            <Store size={12} color="#666" />
            <span>{product.vendorCount} {product.vendorCount === 1 ? 'vendor' : 'vendors'}</span>
          </div>
          {product.nearestDistanceKm > 0 && (
            <div style={styles.metaItem}>
              <MapPin size={12} color="#f97316" />
              <span style={{ color: '#f97316' }}>{product.nearestDistanceKm} km away</span>
            </div>
          )}
        </div>
      </div>

      {/* Multi-vendor badge */}
      {product.vendorCount > 1 && (
        <div style={styles.multiVendorBadge}>
          <Tag size={10} />
          {product.vendorCount} vendors competing — best price inside
        </div>
      )}
    </Link>
  )
}

const styles = {
  card: {
    display: 'block',
    background: '#141414',
    border: '1px solid #222',
    borderRadius: '16px',
    padding: '1.25rem',
    textDecoration: 'none',
    color: 'inherit',
    transition: 'border-color 0.2s, transform 0.2s, box-shadow 0.2s',
    cursor: 'pointer',
    position: 'relative',
    overflow: 'hidden',
  },
  catBadge: {
    display: 'inline-flex', alignItems: 'center', gap: '0.35rem',
    background: 'rgba(249,115,22,0.1)',
    border: '1px solid rgba(249,115,22,0.2)',
    borderRadius: '6px',
    padding: '0.25rem 0.6rem',
    fontSize: '0.72rem', color: '#f97316',
    marginBottom: '0.75rem',
    fontWeight: 500,
  },
  name: {
    fontFamily: 'Syne, sans-serif',
    fontSize: '1rem', fontWeight: 700,
    color: '#f5f5f5', marginBottom: '0.4rem',
    lineHeight: 1.3,
  },
  desc: {
    fontSize: '0.82rem', color: '#555',
    lineHeight: 1.5, marginBottom: '1rem',
  },
  footer: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end',
  },
  priceLabel: { fontSize: '0.7rem', color: '#555', marginBottom: '2px' },
  price: {
    fontFamily: 'Syne, sans-serif',
    fontSize: '1.3rem', fontWeight: 800,
    color: '#f5f5f5',
  },
  unit: { fontSize: '0.7rem', color: '#555' },
  metaCol: {
    display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '0.3rem',
  },
  metaItem: {
    display: 'flex', alignItems: 'center', gap: '0.3rem',
    fontSize: '0.75rem', color: '#666',
  },
  multiVendorBadge: {
    display: 'flex', alignItems: 'center', gap: '0.4rem',
    marginTop: '0.85rem',
    background: 'rgba(16,185,129,0.08)',
    border: '1px solid rgba(16,185,129,0.2)',
    borderRadius: '6px',
    padding: '0.3rem 0.6rem',
    fontSize: '0.7rem', color: '#10b981',
  },
}
