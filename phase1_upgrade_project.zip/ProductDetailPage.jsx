import { useState, useEffect } from 'react'
import { useParams, useSearchParams, Link } from 'react-router-dom'
import { getProductDetail } from '../services/api'
import { useLocation as useUserLocation } from '../context/LocationContext'
import VendorCard from '../components/VendorCard'
import { ArrowLeft, Package, Users, TrendingDown } from 'lucide-react'

export default function ProductDetailPage() {
  const { id } = useParams()
  const [searchParams] = useSearchParams()
  const { location } = useUserLocation()
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)

  const lat = location?.lat || parseFloat(searchParams.get('lat'))
  const lng = location?.lng || parseFloat(searchParams.get('lng'))

  useEffect(() => {
    setLoading(true)
    getProductDetail(id, { lat: isNaN(lat) ? null : lat, lng: isNaN(lng) ? null : lng })
      .then(setProduct)
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [id, lat, lng])

  if (loading) return (
    <div style={styles.loadState}>
      <div style={styles.spinner} />
      <p>Loading product...</p>
      <style>{`@keyframes spin { to { transform: rotate(360deg); }}`}</style>
    </div>
  )

  if (!product) return (
    <div style={styles.loadState}>
      <Package size={40} color="#555" />
      <p>Product not found</p>
      <Link to="/" style={styles.backLink}>← Go back</Link>
    </div>
  )

  const priceDiff = product.vendors?.length > 1
    ? ((product.maxPrice - product.minPrice) / product.minPrice * 100).toFixed(0)
    : 0

  return (
    <div style={styles.page}>
      <div style={styles.container}>

        {/* Breadcrumb */}
        <Link to="/" style={styles.back}>
          <ArrowLeft size={16} /> Back to products
        </Link>

        {/* Product header */}
        <div style={styles.header}>
          <div style={styles.catTag}>
            {product.categoryIcon} {product.categoryName}
          </div>
          <h1 style={styles.title}>{product.productName}</h1>
          <p style={styles.desc}>{product.description}</p>

          {/* Stats row */}
          <div style={styles.statsRow}>
            <div style={styles.stat}>
              <div style={styles.statVal}>₹{product.minPrice?.toLocaleString('en-IN')}</div>
              <div style={styles.statLabel}>Best price</div>
            </div>
            <div style={styles.statDivider} />
            <div style={styles.stat}>
              <div style={styles.statVal}>{product.vendors?.length}</div>
              <div style={styles.statLabel}>Vendors</div>
            </div>
            {priceDiff > 0 && (
              <>
                <div style={styles.statDivider} />
                <div style={styles.stat}>
                  <div style={{ ...styles.statVal, color: '#10b981' }}>Save {priceDiff}%</div>
                  <div style={styles.statLabel}>vs highest price</div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Multi-vendor notice */}
        {product.vendors?.length > 1 && (
          <div style={styles.multiNotice}>
            <Users size={15} color="#f97316" />
            <span>
              <strong>{product.vendors.length} vendors</strong> sell this product — sorted by nearest to you.
              {product.vendors.length >= 2 && ' Top 2 nearest shown first.'}
            </span>
          </div>
        )}

        {/* Price comparison banner if 2+ vendors */}
        {product.vendors?.length >= 2 && (
          <div style={styles.compareBanner}>
            <TrendingDown size={14} color="#10b981" />
            <span>
              Price range: ₹{product.minPrice?.toLocaleString('en-IN')} – ₹{product.maxPrice?.toLocaleString('en-IN')} · Pick the best deal below
            </span>
          </div>
        )}

        {/* Vendor grid - 50/50 split for 2 vendors, else list */}
        <div style={{
          ...styles.vendorGrid,
          gridTemplateColumns: product.vendors?.length === 2 ? '1fr 1fr' : 'repeat(auto-fill, minmax(300px, 1fr))',
        }}>
          {product.vendors?.map((vendor, i) => (
            <VendorCard
              key={vendor.vendorProductId}
              vendor={vendor}
              rank={i}
              totalVendors={product.vendors.length}
            />
          ))}
        </div>

        {product.vendors?.length === 0 && (
          <div style={styles.noVendors}>
            <Package size={40} color="#555" />
            <p>No vendors available nearby for this product</p>
          </div>
        )}
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); }}`}</style>
    </div>
  )
}

const styles = {
  page: { minHeight: '100vh', paddingBottom: '4rem' },
  container: { maxWidth: 1200, margin: '0 auto', padding: '1.5rem' },
  back: {
    display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
    color: '#666', textDecoration: 'none',
    fontSize: '0.85rem', marginBottom: '1.5rem',
    transition: 'color 0.2s',
  },
  header: {
    background: '#141414',
    border: '1px solid #222',
    borderRadius: '20px',
    padding: '2rem',
    marginBottom: '1.25rem',
  },
  catTag: {
    display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
    background: 'rgba(249,115,22,0.1)',
    border: '1px solid rgba(249,115,22,0.2)',
    borderRadius: '6px',
    padding: '0.25rem 0.6rem',
    fontSize: '0.75rem', color: '#f97316',
    marginBottom: '0.85rem',
  },
  title: {
    fontFamily: 'Syne, sans-serif',
    fontSize: 'clamp(1.4rem, 3vw, 2rem)',
    fontWeight: 800, color: '#f5f5f5',
    marginBottom: '0.6rem',
  },
  desc: { fontSize: '0.9rem', color: '#666', lineHeight: 1.6, marginBottom: '1.5rem' },
  statsRow: {
    display: 'flex', alignItems: 'center', gap: '1.5rem',
    flexWrap: 'wrap',
  },
  stat: { textAlign: 'center' },
  statVal: {
    fontFamily: 'Syne, sans-serif',
    fontSize: '1.4rem', fontWeight: 800, color: '#f5f5f5',
  },
  statLabel: { fontSize: '0.72rem', color: '#555' },
  statDivider: { width: 1, height: 40, background: '#222' },
  multiNotice: {
    display: 'flex', alignItems: 'center', gap: '0.6rem',
    background: 'rgba(249,115,22,0.06)',
    border: '1px solid rgba(249,115,22,0.2)',
    borderRadius: '10px', padding: '0.75rem 1rem',
    fontSize: '0.85rem', color: '#aaa',
    marginBottom: '0.75rem',
  },
  compareBanner: {
    display: 'flex', alignItems: 'center', gap: '0.6rem',
    background: 'rgba(16,185,129,0.06)',
    border: '1px solid rgba(16,185,129,0.2)',
    borderRadius: '10px', padding: '0.75rem 1rem',
    fontSize: '0.85rem', color: '#aaa',
    marginBottom: '1.25rem',
  },
  vendorGrid: {
    display: 'grid', gap: '1rem',
  },
  noVendors: {
    textAlign: 'center', padding: '4rem',
    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem',
    color: '#555',
  },
  loadState: {
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    justifyContent: 'center', gap: '1rem',
    minHeight: '50vh', color: '#555', fontSize: '0.9rem',
  },
  spinner: {
    width: 36, height: 36,
    border: '3px solid #222',
    borderTop: '3px solid #f97316',
    borderRadius: '50%',
    animation: 'spin 0.8s linear infinite',
  },
  backLink: { color: '#f97316', textDecoration: 'none', fontSize: '0.85rem' },
}
