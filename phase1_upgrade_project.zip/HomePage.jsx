import { useState, useEffect } from 'react'
import { useLocation } from '../context/LocationContext'
import { getCategories, getProducts } from '../services/api'
import ProductCard from '../components/ProductCard'
import { MapPin, Zap, ChevronRight } from 'lucide-react'

export default function HomePage() {
  const { location, status, requestLocation } = useLocation()
  const [categories, setCategories] = useState([])
  const [products, setProducts] = useState([])
  const [selectedCat, setSelectedCat] = useState(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    getCategories().then(setCategories).catch(console.error)
  }, [])

  useEffect(() => {
    setLoading(true)
    const opts = location
      ? { lat: location.lat, lng: location.lng, radius: 15, categoryId: selectedCat }
      : { categoryId: selectedCat }
    getProducts(opts)
      .then(setProducts)
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [location, selectedCat])

  return (
    <div style={styles.page}>
      {/* Hero */}
      <section style={styles.hero}>
        <div style={styles.heroInner}>
          <div style={styles.heroTag}>
            <Zap size={12} fill="#f97316" color="#f97316" />
            Hyperlocal · Best Price · Instant Stock
          </div>
          <h1 style={styles.heroTitle}>
            Find spare parts<br />
            <span style={styles.accent}>near you</span>
          </h1>
          <p style={styles.heroSub}>
            Compare prices across local vendors. Order from the nearest shop. Delivered fast.
          </p>

          {status !== 'granted' && (
            <button style={styles.heroLocBtn} onClick={requestLocation}>
              <MapPin size={16} />
              Detect my location
            </button>
          )}

          {status === 'granted' && (
            <div style={styles.locGrantedBanner}>
              <MapPin size={14} color="#f97316" />
              Showing vendors within 15 km of you
            </div>
          )}
        </div>

        {/* Decorative grid pattern */}
        <div style={styles.heroBg} aria-hidden="true">
          {Array.from({ length: 80 }).map((_, i) => (
            <div key={i} style={styles.gridDot} />
          ))}
        </div>
      </section>

      <div style={styles.container}>
        {/* Categories */}
        <section style={styles.section}>
          <h2 style={styles.sectionTitle}>Browse by category</h2>
          <div style={styles.catRow}>
            <button
              style={{ ...styles.catChip, ...(selectedCat === null ? styles.catActive : {}) }}
              onClick={() => setSelectedCat(null)}
            >
              All
            </button>
            {categories.map(cat => (
              <button
                key={cat.id}
                style={{ ...styles.catChip, ...(selectedCat === cat.id ? styles.catActive : {}) }}
                onClick={() => setSelectedCat(cat.id)}
              >
                {cat.icon} {cat.name}
                <span style={styles.catCount}>{cat.productCount}</span>
              </button>
            ))}
          </div>
        </section>

        {/* Products grid */}
        <section style={styles.section}>
          <div style={styles.sectionHeader}>
            <h2 style={styles.sectionTitle}>
              {status === 'granted' ? 'Nearby products' : 'All products'}
            </h2>
            <span style={styles.count}>{products.length} found</span>
          </div>

          {loading ? (
            <div style={styles.loadingGrid}>
              {[1,2,3,4,5,6].map(i => <div key={i} style={styles.skeleton} />)}
            </div>
          ) : products.length === 0 ? (
            <div style={styles.empty}>
              <span style={{ fontSize: '2.5rem' }}>📦</span>
              <p>No products found nearby</p>
              <button style={styles.expandBtn} onClick={() => setSelectedCat(null)}>
                Show all categories
              </button>
            </div>
          ) : (
            <div style={styles.grid}>
              {products.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          )}
        </section>
      </div>

      <style>{`
        @keyframes shimmer {
          0% { background-position: -400px 0; }
          100% { background-position: 400px 0; }
        }
        a:hover > div { border-color: rgba(249,115,22,0.4) !important; transform: translateY(-2px); box-shadow: 0 8px 30px rgba(249,115,22,0.08); }
      `}</style>
    </div>
  )
}

const styles = {
  page: { minHeight: '100vh' },
  hero: {
    position: 'relative', overflow: 'hidden',
    borderBottom: '1px solid #1a1a1a',
    padding: '5rem 1.5rem 4rem',
  },
  heroInner: {
    position: 'relative', zIndex: 1,
    maxWidth: 600, margin: '0 auto', textAlign: 'center',
  },
  heroTag: {
    display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
    background: 'rgba(249,115,22,0.1)',
    border: '1px solid rgba(249,115,22,0.25)',
    borderRadius: '100px',
    padding: '0.35rem 0.9rem',
    fontSize: '0.75rem', color: '#f97316',
    fontWeight: 600, marginBottom: '1.5rem',
    letterSpacing: '0.03em',
  },
  heroTitle: {
    fontFamily: 'Syne, sans-serif',
    fontSize: 'clamp(2.2rem, 5vw, 3.5rem)',
    fontWeight: 800, lineHeight: 1.15,
    color: '#f5f5f5', marginBottom: '1rem',
  },
  accent: { color: '#f97316' },
  heroSub: {
    fontSize: '1rem', color: '#666',
    lineHeight: 1.7, marginBottom: '2rem',
  },
  heroLocBtn: {
    display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
    background: '#f97316', color: '#fff',
    border: 'none', borderRadius: '12px',
    padding: '0.85rem 1.75rem',
    fontSize: '0.95rem', fontWeight: 600, cursor: 'pointer',
  },
  locGrantedBanner: {
    display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
    background: 'rgba(249,115,22,0.1)',
    border: '1px solid rgba(249,115,22,0.3)',
    borderRadius: '10px',
    padding: '0.6rem 1.25rem',
    fontSize: '0.85rem', color: '#f97316',
  },
  heroBg: {
    position: 'absolute', inset: 0, zIndex: 0,
    display: 'grid', gridTemplateColumns: 'repeat(10, 1fr)',
    opacity: 0.06, pointerEvents: 'none',
  },
  gridDot: {
    width: 2, height: 2, borderRadius: '50%',
    background: '#f97316', margin: 'auto',
  },
  container: { maxWidth: 1200, margin: '0 auto', padding: '0 1.5rem' },
  section: { paddingTop: '2.5rem', paddingBottom: '1rem' },
  sectionHeader: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    marginBottom: '1.25rem',
  },
  sectionTitle: {
    fontFamily: 'Syne, sans-serif',
    fontSize: '1.2rem', fontWeight: 700, color: '#f5f5f5',
    marginBottom: '1rem',
  },
  count: { fontSize: '0.82rem', color: '#555' },
  catRow: {
    display: 'flex', flexWrap: 'wrap', gap: '0.5rem',
  },
  catChip: {
    display: 'flex', alignItems: 'center', gap: '0.35rem',
    padding: '0.45rem 0.9rem',
    background: '#141414',
    border: '1px solid #222',
    borderRadius: '100px',
    fontSize: '0.82rem', color: '#888',
    cursor: 'pointer',
    transition: 'all 0.2s',
  },
  catActive: {
    background: 'rgba(249,115,22,0.1)',
    borderColor: 'rgba(249,115,22,0.4)',
    color: '#f97316',
  },
  catCount: {
    background: '#1f1f1f',
    borderRadius: '4px',
    padding: '0 0.35rem',
    fontSize: '0.7rem', color: '#555',
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
    gap: '1rem',
  },
  loadingGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
    gap: '1rem',
  },
  skeleton: {
    height: 220, borderRadius: '16px',
    backgroundImage: 'linear-gradient(90deg, #1a1a1a 25%, #222 50%, #1a1a1a 75%)',
    backgroundSize: '800px 100%',
    animation: 'shimmer 1.5s infinite linear',
  },
  empty: {
    textAlign: 'center', padding: '4rem 1rem',
    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem',
    color: '#555',
  },
  expandBtn: {
    background: '#f97316', color: '#fff',
    border: 'none', borderRadius: '10px',
    padding: '0.6rem 1.25rem',
    fontSize: '0.85rem', fontWeight: 600, cursor: 'pointer',
  },
}
