import { useEffect } from 'react'
import { MapPin, Navigation, X } from 'lucide-react'
import { useLocation } from '../context/LocationContext'

export default function LocationModal() {
  const { status, error, requestLocation, clearLocation } = useLocation()

  // Auto-ask on first load
  useEffect(() => {
    if (status === 'idle') {
      // Small delay so page renders first
      const t = setTimeout(() => {}, 300)
      return () => clearTimeout(t)
    }
  }, [])

  if (status !== 'idle' && status !== 'denied') return null

  return (
    <div style={styles.overlay}>
      <div style={styles.modal}>
        {/* Animated pin */}
        <div style={styles.iconWrap}>
          <div style={styles.pulse} />
          <MapPin size={36} color="#f97316" strokeWidth={1.5} />
        </div>

        <h2 style={styles.title}>Find parts near you</h2>
        <p style={styles.sub}>
          SpareHub needs your location to show nearby vendors, real-time prices, and estimated delivery time.
        </p>

        {status === 'denied' && (
          <div style={styles.errorBox}>
            <span>📍 Location denied. {error}</span>
          </div>
        )}

        <button style={styles.primaryBtn} onClick={requestLocation}>
          <Navigation size={16} />
          {status === 'denied' ? 'Try again' : 'Allow location access'}
        </button>

        <button style={styles.skipBtn} onClick={clearLocation}>
          Browse without location
        </button>

        <p style={styles.note}>We never store or share your location.</p>
      </div>

      <style>{`
        @keyframes pulse-ring {
          0% { transform: scale(0.8); opacity: 0.8; }
          100% { transform: scale(2); opacity: 0; }
        }
        @keyframes modal-in {
          from { opacity: 0; transform: translateY(20px) scale(0.97); }
          to   { opacity: 1; transform: translateY(0) scale(1); }
        }
      `}</style>
    </div>
  )
}

const styles = {
  overlay: {
    position: 'fixed', inset: 0,
    background: 'rgba(0,0,0,0.75)',
    backdropFilter: 'blur(6px)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    zIndex: 1000, padding: '1rem',
  },
  modal: {
    background: '#1a1a1a',
    border: '1px solid #2a2a2a',
    borderRadius: '20px',
    padding: '2.5rem 2rem',
    maxWidth: '420px', width: '100%',
    textAlign: 'center',
    animation: 'modal-in 0.35s cubic-bezier(0.34,1.56,0.64,1)',
  },
  iconWrap: {
    position: 'relative',
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    width: 72, height: 72,
    background: 'rgba(249,115,22,0.1)',
    borderRadius: '50%',
    marginBottom: '1.25rem',
  },
  pulse: {
    position: 'absolute', inset: 0,
    borderRadius: '50%',
    border: '2px solid rgba(249,115,22,0.5)',
    animation: 'pulse-ring 1.8s ease-out infinite',
  },
  title: {
    fontFamily: 'Syne, sans-serif',
    fontSize: '1.5rem', fontWeight: 700,
    color: '#f5f5f5', marginBottom: '0.75rem',
  },
  sub: {
    fontSize: '0.9rem', color: '#888',
    lineHeight: 1.6, marginBottom: '1.5rem',
  },
  errorBox: {
    background: 'rgba(239,68,68,0.1)',
    border: '1px solid rgba(239,68,68,0.3)',
    borderRadius: '10px',
    padding: '0.75rem', marginBottom: '1rem',
    fontSize: '0.85rem', color: '#f87171',
  },
  primaryBtn: {
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
    width: '100%',
    padding: '0.85rem',
    background: '#f97316',
    color: '#fff',
    border: 'none', borderRadius: '12px',
    fontSize: '0.95rem', fontWeight: 600,
    cursor: 'pointer', marginBottom: '0.75rem',
    transition: 'background 0.2s',
  },
  skipBtn: {
    width: '100%', padding: '0.75rem',
    background: 'transparent',
    color: '#666',
    border: '1px solid #2a2a2a',
    borderRadius: '12px',
    fontSize: '0.9rem', cursor: 'pointer',
    marginBottom: '1rem',
    transition: 'color 0.2s, border-color 0.2s',
  },
  note: {
    fontSize: '0.75rem', color: '#444',
  },
}
