package com.sparehub.controller;

import com.sparehub.dto.Dtos.*;
import com.sparehub.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ApiController {

    private final ProductService productService;

    // ─── GET /api/categories ─────────────────────────────────────────────
    @GetMapping("/categories")
    public ResponseEntity<ApiResponse<List<CategoryDto>>> getCategories() {
        return ResponseEntity.ok(ApiResponse.ok(productService.getAllCategories()));
    }

    // ─── GET /api/products?lat=18.52&lng=73.85&radius=10&categoryId=1 ───
    @GetMapping("/products")
    public ResponseEntity<ApiResponse<List<ProductSummaryDto>>> getProducts(
            @RequestParam(required = false) Double lat,
            @RequestParam(required = false) Double lng,
            @RequestParam(defaultValue = "10") Double radius,
            @RequestParam(required = false) Long categoryId) {

        List<ProductSummaryDto> products = productService.getNearbyProducts(lat, lng, radius, categoryId);
        String msg = (lat != null) ? "Showing products within " + radius + " km" : "Showing all products";
        return ResponseEntity.ok(ApiResponse.ok(msg, products));
    }

    // ─── GET /api/products/{id}?lat=18.52&lng=73.85 ──────────────────────
    @GetMapping("/products/{id}")
    public ResponseEntity<ApiResponse<ProductWithVendorsDto>> getProductDetail(
            @PathVariable Long id,
            @RequestParam(required = false) Double lat,
            @RequestParam(required = false) Double lng) {

        return productService.getProductDetail(id, lat, lng)
                .map(dto -> ResponseEntity.ok(ApiResponse.ok(dto)))
                .orElse(ResponseEntity.notFound().build());
    }

    // ─── GET /api/search?q=battery&lat=18.52&lng=73.85 ───────────────────
    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<ProductSummaryDto>>> search(
            @RequestParam String q,
            @RequestParam(required = false) Double lat,
            @RequestParam(required = false) Double lng) {

        List<ProductSummaryDto> results = productService.searchProducts(q, lat, lng);
        return ResponseEntity.ok(ApiResponse.ok("Found " + results.size() + " results for '" + q + "'", results));
    }

    // ─── Health check ─────────────────────────────────────────────────────
    @GetMapping("/health")
    public ResponseEntity<ApiResponse<String>> health() {
        return ResponseEntity.ok(ApiResponse.ok("SpareHub API is running", "OK"));
    }
}
