# SpareHub — Phase 1
## Hyperlocal Multi-Vendor Marketplace for Spare Parts

---

## Project Structure

```
sparehub/
├── database/
│   └── schema.sql              ← Run this first
├── backend/                    ← Spring Boot (Java 17)
│   ├── pom.xml
│   └── src/main/java/com/sparehub/
│       ├── SpareHubApplication.java
│       ├── config/CorsConfig.java
│       ├── controller/ApiController.java
│       ├── dto/Dtos.java
│       ├── model/              ← Category, Product, Vendor, VendorProduct
│       ├── repository/Repositories.java
│       └── service/ProductService.java
└── frontend/                   ← React + Vite
    ├── src/
    │   ├── App.jsx
    │   ├── main.jsx
    │   ├── context/LocationContext.jsx
    │   ├── services/api.js
    │   ├── components/
    │   │   ├── Navbar.jsx
    │   │   ├── LocationModal.jsx
    │   │   ├── ProductCard.jsx
    │   │   └── VendorCard.jsx
    │   └── pages/
    │       ├── HomePage.jsx
    │       ├── ProductDetailPage.jsx
    │       └── SearchPage.jsx
    └── package.json
```

---

## Setup Instructions

### Step 1 — MySQL Database

```sql
-- Open MySQL and run:
mysql -u root -p < database/schema.sql
```

This creates the `sparehub` database with all tables + seed data (vendors in Pune).

---

### Step 2 — Backend (Spring Boot)

Edit `backend/src/main/resources/application.properties`:
```properties
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD
```

Then run:
```bash
cd backend
mvn spring-boot:run
```

Backend starts on **http://localhost:8080**

Test it:
```
GET http://localhost:8080/api/health
GET http://localhost:8080/api/categories
GET http://localhost:8080/api/products
GET http://localhost:8080/api/products?lat=18.52&lng=73.85&radius=10
GET http://localhost:8080/api/products/1?lat=18.52&lng=73.85
GET http://localhost:8080/api/search?q=battery&lat=18.52&lng=73.85
```

---

### Step 3 — Frontend (React)

```bash
cd frontend
npm install
npm run dev
```

Frontend starts on **http://localhost:3000**

---

## How It Works

### Location Flow
1. User opens the site → **location modal pops up** asking for GPS
2. If allowed → all products show distance from user
3. API filters vendors within 15 km radius automatically
4. If denied → site still works, shows all products without distance

### Multi-Vendor Logic
- Product detail page shows **all vendors** selling that product
- Sorted by **nearest first** (Haversine formula in backend)
- If exactly **2 vendors** → 50/50 split layout side by side
- Price comparison banner shows min/max and savings %
- "Call & Order" button dials the vendor directly

### API Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /api/categories` | All categories with product count |
| `GET /api/products` | All products (with optional lat/lng/radius/categoryId) |
| `GET /api/products/{id}` | Product detail with all vendor offers |
| `GET /api/search?q=` | Full-text search across product name + description |
| `GET /api/health` | Health check |

---

## DB Tables

| Table | Purpose |
|-------|---------|
| `customers` | Registered users (Phase 2) |
| `vendors` | Shop owners with GPS coordinates |
| `categories` | Product categories |
| `products` | Master product list |
| `vendor_products` | Price + stock per vendor per product |

---

## Phase 2 Preview (next)
- Customer login + OTP via Fast2SMS
- Order placement → vendor push notification (FCM)
- Vendor accept/reject → auto-reassign if rejected
- OTP delivery confirmation
- Live ETA tracking

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Spring Boot 3.2, Java 17 |
| Database | MySQL 8 + JPA/Hibernate |
| Frontend | React 18 + Vite |
| Styling | Inline CSS + Google Fonts (Syne + DM Sans) |
| Routing | React Router v6 |
| HTTP | Axios |
| Distance | Haversine formula (server-side) |
