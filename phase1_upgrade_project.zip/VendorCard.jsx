import { MapPin, Phone, Star, ShieldCheck, Package } from 'lucide-react'

export default function VendorCard({ vendor, rank, totalVendors }) {
  const isBestPrice = rank === 0
  const isNearest = rank === 0 // sorted by distance from API

  // 50/50 split: highlight top 2 equally if multiple vendors
  const highlight = totalVendors > 1 && rank < 2

  return (
    <div style={{
      ...styles.card,
      ...(isBestPrice ? styles.bestCard : {}),
      ...(highlight ? styles.highlightCard : {}),
    }}>
      {/* Rank badge */}
      <div style={styles.header}>
        <div style={styles.rankBadge}>
          {isBestPrice && totalVendors > 1
            ? <span style={styles.bestBadge}>🏆 Nearest</span>
            : <span style={styles.rankNum}>#{rank + 1}</span>
          }
        </div>

        {vendor.isVerified && (
          <div style={styles.verified}>
            <ShieldCheck size={12} />
            Verified
          </div>
        )}
      </div>

      {/* Shop info */}
      <h3 style={styles.shopName}>{vendor.shopName}</h3>
      <p style={styles.ownerName}>Owner: {vendor.ownerName}</p>

      {/* Rating */}
      {vendor.rating > 0 && (
        <div style={styles.rating}>
          <Star size={13} fill="#f97316" color="#f97316" />
          <span>{vendor.rating.toFixed(1)}</span>
        </div>
      )}

      {/* Location */}
      <div style={styles.infoRow}>
        <MapPin size={13} color="#f97316" />
        <span>{vendor.address}</span>
        {vendor.distanceKm > 0 && (
          <span style={styles.distancePill}>{vendor.distanceKm} km</span>
        )}
      </div>

      {/* Phone */}
      <div style={styles.infoRow}>
        <Phone size={13} color="#666" />
        <a href={`tel:${vendor.phone}`} style={styles.phone}>{vendor.phone}</a>
      </div>

      {/* Stock */}
      <div style={styles.infoRow}>
        <Package size={13} color="#666" />
        <span style={{ color: vendor.stockQty > 0 ? '#10b981' : '#ef4444' }}>
          {vendor.stockQty > 0 ? `${vendor.stockQty} in stock` : 'Out of stock'}
        </span>
      </div>

      {/* Price */}
      <div style={styles.priceRow}>
        <div>
          <div style={styles.priceLabel}>Price</div>
          <div style={styles.price}>₹{vendor.price?.toLocaleString('en-IN')}</div>
        </div>

        <a href={`tel:${vendor.phone}`} style={styles.callBtn}>
          <Phone size={14} />
          Call & Order
        </a>
      </div>
    </div>
  )
}

const styles = {
  card: {
    background: '#141414',
    border: '1px solid #222',
    borderRadius: '16px',
    padding: '1.25rem',
    display: 'flex', flexDirection: 'column', gap: '0.6rem',
  },
  bestCard: {
    borderColor: 'rgba(249,115,22,0.4)',
    background: 'rgba(249,115,22,0.04)',
  },
  highlightCard: {
    borderColor: '#2a2a2a',
  },
  header: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
  },
  rankBadge: { display: 'flex', alignItems: 'center', gap: '0.4rem' },
  bestBadge: {
    fontSize: '0.75rem', color: '#f97316', fontWeight: 700,
  },
  rankNum: {
    fontSize: '0.75rem', color: '#555',
  },
  verified: {
    display: 'flex', alignItems: 'center', gap: '0.3rem',
    fontSize: '0.72rem', color: '#10b981',
    background: 'rgba(16,185,129,0.1)',
    border: '1px solid rgba(16,185,129,0.2)',
    borderRadius: '5px', padding: '0.2rem 0.5rem',
  },
  shopName: {
    fontFamily: 'Syne, sans-serif',
    fontSize: '1.05rem', fontWeight: 700, color: '#f5f5f5',
  },
  ownerName: { fontSize: '0.78rem', color: '#555' },
  rating: {
    display: 'flex', alignItems: 'center', gap: '0.3rem',
    fontSize: '0.82rem', color: '#f97316',
  },
  infoRow: {
    display: 'flex', alignItems: 'center', gap: '0.4rem',
    fontSize: '0.82rem', color: '#777',
  },
  distancePill: {
    background: 'rgba(249,115,22,0.1)',
    color: '#f97316',
    borderRadius: '4px', padding: '0.1rem 0.4rem',
    fontSize: '0.72rem', fontWeight: 600, marginLeft: 'auto',
  },
  phone: { color: '#f5f5f5', textDecoration: 'none', fontWeight: 500 },
  priceRow: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end',
    marginTop: '0.5rem',
    paddingTop: '0.75rem',
    borderTop: '1px solid #1f1f1f',
  },
  priceLabel: { fontSize: '0.7rem', color: '#555', marginBottom: '2px' },
  price: {
    fontFamily: 'Syne, sans-serif',
    fontSize: '1.4rem', fontWeight: 800, color: '#f5f5f5',
  },
  callBtn: {
    display: 'flex', alignItems: 'center', gap: '0.4rem',
    background: '#f97316', color: '#fff',
    border: 'none', borderRadius: '10px',
    padding: '0.6rem 1rem',
    fontSize: '0.85rem', fontWeight: 600,
    cursor: 'pointer', textDecoration: 'none',
  },
}
