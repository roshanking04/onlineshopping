package com.sparehub.dto;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.util.List;

public class Dtos {

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class VendorOfferDto {
        private Long vendorProductId;
        private Long vendorId;
        private String shopName;
        private String ownerName;
        private String phone;
        private String address;
        private Double lat;
        private Double lng;
        private BigDecimal price;
        private Integer stockQty;
        private Double rating;
        private Boolean isVerified;
        private Double distanceKm;  // calculated from user location
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ProductWithVendorsDto {
        private Long productId;
        private String productName;
        private String description;
        private String unit;
        private String imageUrl;
        private String categoryName;
        private String categoryIcon;
        private List<VendorOfferDto> vendors;
        private BigDecimal minPrice;
        private BigDecimal maxPrice;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class CategoryDto {
        private Long id;
        private String name;
        private String icon;
        private String description;
        private Long productCount;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ProductSummaryDto {
        private Long id;
        private String name;
        private String description;
        private String unit;
        private String imageUrl;
        private String categoryName;
        private String categoryIcon;
        private BigDecimal minPrice;
        private Integer vendorCount;
        private Double nearestDistanceKm;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ApiResponse<T> {
        private boolean success;
        private String message;
        private T data;

        public static <T> ApiResponse<T> ok(T data) {
            return new ApiResponse<>(true, "Success", data);
        }

        public static <T> ApiResponse<T> ok(String message, T data) {
            return new ApiResponse<>(true, message, data);
        }

        public static <T> ApiResponse<T> error(String message) {
            return new ApiResponse<>(false, message, null);
        }
    }
}
