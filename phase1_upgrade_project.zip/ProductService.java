package com.sparehub.service;

import com.sparehub.dto.Dtos.*;
import com.sparehub.model.*;
import com.sparehub.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final VendorProductRepository vendorProductRepo;
    private final ProductRepository productRepo;
    private final CategoryRepository categoryRepo;

    // ─── Haversine formula to calculate distance in km ─────────────────────
    public static double distanceKm(double lat1, double lon1, double lat2, double lon2) {
        final int R = 6371;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                 + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                 * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    // ─── Convert VendorProduct → VendorOfferDto ──────────────────────────
    private VendorOfferDto toVendorOffer(VendorProduct vp, Double userLat, Double userLng) {
        Vendor v = vp.getVendor();
        double dist = (userLat != null && userLng != null)
                ? distanceKm(userLat, userLng, v.getLat(), v.getLng())
                : 0.0;

        VendorOfferDto dto = new VendorOfferDto();
        dto.setVendorProductId(vp.getId());
        dto.setVendorId(v.getId());
        dto.setShopName(v.getShopName());
        dto.setOwnerName(v.getOwnerName());
        dto.setPhone(v.getPhone());
        dto.setAddress(v.getAddress());
        dto.setLat(v.getLat());
        dto.setLng(v.getLng());
        dto.setPrice(vp.getPrice());
        dto.setStockQty(vp.getStockQty());
        dto.setRating(v.getRating());
        dto.setIsVerified(v.getIsVerified());
        dto.setDistanceKm(Math.round(dist * 10.0) / 10.0);
        return dto;
    }

    // ─── Get all categories with product count ───────────────────────────
    public List<CategoryDto> getAllCategories() {
        return categoryRepo.findAll().stream().map(c -> {
            long count = productRepo.findByCategoryId(c.getId()).size();
            return new CategoryDto(c.getId(), c.getName(), c.getIcon(), c.getDescription(), count);
        }).collect(Collectors.toList());
    }

    // ─── Get products near user location ─────────────────────────────────
    public List<ProductSummaryDto> getNearbyProducts(Double userLat, Double userLng, Double radiusKm, Long categoryId) {
        List<VendorProduct> allVPs = (categoryId != null)
                ? vendorProductRepo.findByCategoryId(categoryId)
                : vendorProductRepo.findAll().stream()
                    .filter(vp -> vp.getIsAvailable() && vp.getVendor().getIsActive())
                    .collect(Collectors.toList());

        // Filter by radius if location provided
        if (userLat != null && userLng != null) {
            allVPs = allVPs.stream().filter(vp -> {
                double d = distanceKm(userLat, userLng, vp.getVendor().getLat(), vp.getVendor().getLng());
                return d <= radiusKm;
            }).collect(Collectors.toList());
        }

        // Group by product
        Map<Long, List<VendorProduct>> byProduct = allVPs.stream()
                .collect(Collectors.groupingBy(vp -> vp.getProduct().getId()));

        return byProduct.entrySet().stream().map(entry -> {
            List<VendorProduct> vps = entry.getValue();
            Product p = vps.get(0).getProduct();

            BigDecimal minPrice = vps.stream().map(VendorProduct::getPrice).min(Comparator.naturalOrder()).orElse(BigDecimal.ZERO);

            Double nearestDist = (userLat != null && userLng != null)
                    ? vps.stream().mapToDouble(vp -> distanceKm(userLat, userLng, vp.getVendor().getLat(), vp.getVendor().getLng())).min().orElse(0)
                    : 0.0;

            return new ProductSummaryDto(
                    p.getId(), p.getName(), p.getDescription(), p.getUnit(), p.getImageUrl(),
                    p.getCategory().getName(), p.getCategory().getIcon(),
                    minPrice, vps.size(), Math.round(nearestDist * 10.0) / 10.0
            );
        }).sorted(Comparator.comparingDouble(ProductSummaryDto::getNearestDistanceKm))
          .collect(Collectors.toList());
    }

    // ─── Get product detail with all vendor offers ────────────────────────
    public Optional<ProductWithVendorsDto> getProductDetail(Long productId, Double userLat, Double userLng) {
        List<VendorProduct> vps = vendorProductRepo.findByProductId(productId);
        if (vps.isEmpty()) return Optional.empty();

        Product p = vps.get(0).getProduct();

        List<VendorOfferDto> vendorOffers = vps.stream()
                .map(vp -> toVendorOffer(vp, userLat, userLng))
                .sorted(Comparator.comparingDouble(VendorOfferDto::getDistanceKm))
                .collect(Collectors.toList());

        BigDecimal minPrice = vendorOffers.stream().map(VendorOfferDto::getPrice).min(Comparator.naturalOrder()).orElse(BigDecimal.ZERO);
        BigDecimal maxPrice = vendorOffers.stream().map(VendorOfferDto::getPrice).max(Comparator.naturalOrder()).orElse(BigDecimal.ZERO);

        return Optional.of(new ProductWithVendorsDto(
                p.getId(), p.getName(), p.getDescription(), p.getUnit(), p.getImageUrl(),
                p.getCategory().getName(), p.getCategory().getIcon(),
                vendorOffers, minPrice, maxPrice
        ));
    }

    // ─── Search products ─────────────────────────────────────────────────
    public List<ProductSummaryDto> searchProducts(String keyword, Double userLat, Double userLng) {
        List<VendorProduct> vps = vendorProductRepo.searchByKeyword(keyword);

        Map<Long, List<VendorProduct>> byProduct = vps.stream()
                .collect(Collectors.groupingBy(vp -> vp.getProduct().getId()));

        return byProduct.entrySet().stream().map(entry -> {
            List<VendorProduct> list = entry.getValue();
            Product p = list.get(0).getProduct();
            BigDecimal minPrice = list.stream().map(VendorProduct::getPrice).min(Comparator.naturalOrder()).orElse(BigDecimal.ZERO);
            Double nearestDist = (userLat != null && userLng != null)
                    ? list.stream().mapToDouble(vp -> distanceKm(userLat, userLng, vp.getVendor().getLat(), vp.getVendor().getLng())).min().orElse(0)
                    : 0.0;
            return new ProductSummaryDto(p.getId(), p.getName(), p.getDescription(), p.getUnit(), p.getImageUrl(),
                    p.getCategory().getName(), p.getCategory().getIcon(), minPrice, list.size(), Math.round(nearestDist * 10.0) / 10.0);
        }).sorted(Comparator.comparingDouble(ProductSummaryDto::getNearestDistanceKm))
          .collect(Collectors.toList());
    }
}
