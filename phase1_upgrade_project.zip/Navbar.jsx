import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Search, MapPin, Package, Menu, X } from 'lucide-react'
import { useLocation } from '../context/LocationContext'

export default function Navbar() {
  const [query, setQuery] = useState('')
  const [menuOpen, setMenuOpen] = useState(false)
  const { location, status, requestLocation } = useLocation()
  const navigate = useNavigate()

  const handleSearch = (e) => {
    e.preventDefault()
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query.trim())}`)
      setQuery('')
    }
  }

  return (
    <nav style={styles.nav}>
      <div style={styles.inner}>
        {/* Logo */}
        <Link to="/" style={styles.logo}>
          <Package size={22} color="#f97316" strokeWidth={2} />
          <span>Spare<span style={{ color: '#f97316' }}>Hub</span></span>
        </Link>

        {/* Search bar */}
        <form style={styles.searchForm} onSubmit={handleSearch}>
          <Search size={16} color="#666" style={{ flexShrink: 0 }} />
          <input
            style={styles.searchInput}
            placeholder="Search batteries, parts, scrap..."
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
          <button type="submit" style={styles.searchBtn}>Search</button>
        </form>

        {/* Location badge */}
        <button
          style={{
            ...styles.locBadge,
            ...(status === 'granted' ? styles.locGranted : {}),
          }}
          onClick={requestLocation}
        >
          <MapPin size={14} />
          <span style={{ fontSize: '0.8rem' }}>
            {status === 'granted'
              ? `${location.lat.toFixed(2)}, ${location.lng.toFixed(2)}`
              : 'Set location'}
          </span>
        </button>
      </div>
    </nav>
  )
}

const styles = {
  nav: {
    position: 'sticky', top: 0, zIndex: 100,
    background: 'rgba(15,15,15,0.92)',
    backdropFilter: 'blur(12px)',
    borderBottom: '1px solid #1f1f1f',
  },
  inner: {
    maxWidth: 1200, margin: '0 auto',
    padding: '0.85rem 1.5rem',
    display: 'flex', alignItems: 'center', gap: '1rem',
  },
  logo: {
    display: 'flex', alignItems: 'center', gap: '0.5rem',
    fontFamily: 'Syne, sans-serif',
    fontSize: '1.3rem', fontWeight: 800,
    color: '#f5f5f5',
    textDecoration: 'none', flexShrink: 0,
  },
  searchForm: {
    flex: 1,
    display: 'flex', alignItems: 'center', gap: '0.5rem',
    background: '#1a1a1a',
    border: '1px solid #2a2a2a',
    borderRadius: '10px',
    padding: '0.5rem 0.75rem',
  },
  searchInput: {
    flex: 1, background: 'none', border: 'none', outline: 'none',
    color: '#f5f5f5', fontSize: '0.9rem',
    fontFamily: 'DM Sans, sans-serif',
  },
  searchBtn: {
    background: '#f97316', color: '#fff',
    border: 'none', borderRadius: '7px',
    padding: '0.35rem 0.85rem',
    fontSize: '0.82rem', fontWeight: 600,
    cursor: 'pointer', flexShrink: 0,
  },
  locBadge: {
    display: 'flex', alignItems: 'center', gap: '0.4rem',
    background: '#1a1a1a',
    border: '1px solid #2a2a2a',
    borderRadius: '8px',
    padding: '0.45rem 0.75rem',
    color: '#888', cursor: 'pointer',
    flexShrink: 0, whiteSpace: 'nowrap',
  },
  locGranted: {
    borderColor: 'rgba(249,115,22,0.4)',
    color: '#f97316',
  },
}
