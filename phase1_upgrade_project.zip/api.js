import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 10000,
})

export const getCategories = () => api.get('/categories').then(r => r.data.data)

export const getProducts = ({ lat, lng, radius = 10, categoryId } = {}) => {
  const params = { radius }
  if (lat != null) params.lat = lat
  if (lng != null) params.lng = lng
  if (categoryId) params.categoryId = categoryId
  return api.get('/products', { params }).then(r => r.data.data)
}

export const getProductDetail = (id, { lat, lng } = {}) => {
  const params = {}
  if (lat != null) params.lat = lat
  if (lng != null) params.lng = lng
  return api.get(`/products/${id}`, { params }).then(r => r.data.data)
}

export const searchProducts = (q, { lat, lng } = {}) => {
  const params = { q }
  if (lat != null) params.lat = lat
  if (lng != null) params.lng = lng
  return api.get('/search', { params }).then(r => r.data.data)
}
