import { createContext, useContext, useState, useCallback } from 'react'

const LocationContext = createContext(null)

export function LocationProvider({ children }) {
  const [location, setLocation] = useState(null)       // { lat, lng, city }
  const [status, setStatus] = useState('idle')          // idle | asking | granted | denied | error
  const [error, setError] = useState(null)

  const requestLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setStatus('error')
      setError('Geolocation is not supported by your browser.')
      return
    }
    setStatus('asking')
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude })
        setStatus('granted')
        setError(null)
      },
      (err) => {
        setStatus('denied')
        setError(err.message)
      },
      { timeout: 10000, maximumAge: 60000 }
    )
  }, [])

  const clearLocation = useCallback(() => {
    setLocation(null)
    setStatus('idle')
  }, [])

  return (
    <LocationContext.Provider value={{ location, status, error, requestLocation, clearLocation }}>
      {children}
    </LocationContext.Provider>
  )
}

export const useLocation = () => useContext(LocationContext)
