import { useState, useEffect } from 'react'
import { useSearchParams } from 'react-router-dom'
import { searchProducts } from '../services/api'
import { useLocation } from '../context/LocationContext'
import ProductCard from '../components/ProductCard'
import { Search } from 'lucide-react'

export default function SearchPage() {
  const [searchParams] = useSearchParams()
  const { location } = useLocation()
  const q = searchParams.get('q') || ''
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!q) return
    setLoading(true)
    searchProducts(q, {
      lat: location?.lat,
      lng: location?.lng,
    })
      .then(setResults)
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [q, location])

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <div style={styles.header}>
          <Search size={20} color="#f97316" />
          <h1 style={styles.title}>
            Results for <span style={styles.accent}>"{q}"</span>
          </h1>
          {!loading && <span style={styles.count}>{results.length} found</span>}
        </div>

        {loading ? (
          <div style={styles.loadingGrid}>
            {[1,2,3].map(i => <div key={i} style={styles.skeleton} />)}
          </div>
        ) : results.length === 0 ? (
          <div style={styles.empty}>
            <span style={{ fontSize: '3rem' }}>🔍</span>
            <p>No products found for "{q}"</p>
            <p style={{ fontSize: '0.82rem', color: '#444' }}>Try a different keyword or browse by category</p>
          </div>
        ) : (
          <div style={styles.grid}>
            {results.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        )}
      </div>
      <style>{`
        @keyframes shimmer { 0% { background-position: -400px 0; } 100% { background-position: 400px 0; }}
        a:hover > div { border-color: rgba(249,115,22,0.4) !important; transform: translateY(-2px); }
      `}</style>
    </div>
  )
}

const styles = {
  page: { minHeight: '100vh', paddingBottom: '4rem' },
  container: { maxWidth: 1200, margin: '0 auto', padding: '2rem 1.5rem' },
  header: {
    display: 'flex', alignItems: 'center', gap: '0.75rem',
    marginBottom: '2rem', flexWrap: 'wrap',
  },
  title: {
    fontFamily: 'Syne, sans-serif',
    fontSize: '1.4rem', fontWeight: 700, color: '#f5f5f5',
  },
  accent: { color: '#f97316' },
  count: { fontSize: '0.82rem', color: '#555', marginLeft: 'auto' },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
    gap: '1rem',
  },
  loadingGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
    gap: '1rem',
  },
  skeleton: {
    height: 220, borderRadius: '16px',
    backgroundImage: 'linear-gradient(90deg, #1a1a1a 25%, #222 50%, #1a1a1a 75%)',
    backgroundSize: '800px 100%',
    animation: 'shimmer 1.5s infinite linear',
  },
  empty: {
    textAlign: 'center', padding: '5rem 1rem',
    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.75rem',
    color: '#666',
  },
}
