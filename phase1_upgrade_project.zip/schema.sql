-- SpareHub Database Schema - Phase 1
CREATE DATABASE IF NOT EXISTS sparehub;
USE sparehub;

CREATE TABLE customers (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    phone VARCHAR(15) UNIQUE NOT NULL,
    email VARCHAR(100),
    lat DOUBLE,
    lng DOUBLE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE vendors (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    shop_name VARCHAR(150) NOT NULL,
    owner_name VARCHAR(100) NOT NULL,
    phone VARCHAR(15) UNIQUE NOT NULL,
    email VARCHAR(100),
    address TEXT,
    lat DOUBLE NOT NULL,
    lng DOUBLE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_verified BOOLEAN DEFAULT FALSE,
    rating DOUBLE DEFAULT 0.0,
    total_ratings INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categories (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    icon VARCHAR(50),
    description TEXT
);

CREATE TABLE products (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    category_id BIGINT,
    image_url VARCHAR(500),
    unit VARCHAR(50) DEFAULT 'piece',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE vendor_products (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    vendor_id BIGINT NOT NULL,
    product_id BIGINT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock_qty INT DEFAULT 0,
    is_available BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id),
    FOREIGN KEY (product_id) REFERENCES products(id),
    UNIQUE KEY unique_vendor_product (vendor_id, product_id)
);

-- Seed categories
INSERT INTO categories (name, icon, description) VALUES
('Batteries', '🔋', 'All types of batteries'),
('Spare Parts', '⚙️', 'Vehicle and machine spare parts'),
('Scrap Metal', '🔩', 'Metal scrap materials'),
('Electronics', '💡', 'Electronic components'),
('Tools', '🔧', 'Hand tools and power tools');

-- Seed sample vendors
INSERT INTO vendors (shop_name, owner_name, phone, address, lat, lng, is_active, is_verified, rating) VALUES
('Sharma Auto Parts', 'Ramesh Sharma', '9876543210', 'MG Road, Pune', 18.5204, 73.8567, TRUE, TRUE, 4.5),
('Kumar Battery House', 'Suresh Kumar', '9876543211', 'FC Road, Pune', 18.5300, 73.8450, TRUE, TRUE, 4.2),
('Patel Spare World', 'Vijay Patel', '9876543212', 'Kothrud, Pune', 18.5074, 73.8077, TRUE, TRUE, 4.7),
('Singh Auto Store', 'Gurpreet Singh', '9876543213', 'Hadapsar, Pune', 18.5089, 73.9260, TRUE, FALSE, 3.9);

-- Seed sample products
INSERT INTO products (name, description, category_id, unit) VALUES
('Car Battery 12V 35Ah', 'Standard 12V car battery suitable for small cars', 1, 'piece'),
('Bike Battery 12V 5Ah', 'Motorcycle battery, maintenance free', 1, 'piece'),
('Inverter Battery 150Ah', 'Tubular inverter battery with 3 year warranty', 1, 'piece'),
('Brake Pads - Maruti', 'OEM quality brake pads for Maruti vehicles', 2, 'set'),
('Engine Oil Filter', 'Universal engine oil filter', 2, 'piece'),
('Alternator Belt', 'V-belt for alternator', 2, 'piece'),
('Copper Wire Scrap', 'Pure copper wire scrap per kg', 3, 'kg'),
('Aluminium Scrap', 'Aluminium casting scrap', 3, 'kg'),
('Headlight Bulb H4', 'Halogen H4 headlight bulb 12V 60/55W', 4, 'piece'),
('Multimeter Digital', 'Digital multimeter with auto range', 5, 'piece');

-- Seed vendor products (prices vary per vendor)
INSERT INTO vendor_products (vendor_id, product_id, price, stock_qty, is_available) VALUES
(1, 1, 3200.00, 15, TRUE),
(2, 1, 2999.00, 8, TRUE),
(3, 1, 3100.00, 20, TRUE),
(1, 2, 650.00, 30, TRUE),
(2, 2, 599.00, 25, TRUE),
(1, 3, 8500.00, 5, TRUE),
(3, 3, 8200.00, 10, TRUE),
(4, 3, 8800.00, 3, TRUE),
(1, 4, 450.00, 50, TRUE),
(3, 4, 420.00, 40, TRUE),
(2, 5, 120.00, 100, TRUE),
(4, 5, 110.00, 80, TRUE),
(1, 6, 280.00, 25, TRUE),
(1, 9, 180.00, 60, TRUE),
(3, 9, 160.00, 45, TRUE),
(2, 10, 850.00, 10, TRUE);
