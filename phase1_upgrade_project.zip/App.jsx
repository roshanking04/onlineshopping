import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { LocationProvider } from './context/LocationContext'
import LocationModal from './components/LocationModal'
import Navbar from './components/Navbar'
import HomePage from './pages/HomePage'
import ProductDetailPage from './pages/ProductDetailPage'
import SearchPage from './pages/SearchPage'

export default function App() {
  return (
    <BrowserRouter>
      <LocationProvider>
        <LocationModal />
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/product/:id" element={<ProductDetailPage />} />
          <Route path="/search" element={<SearchPage />} />
        </Routes>
      </LocationProvider>
    </BrowserRouter>
  )
}
