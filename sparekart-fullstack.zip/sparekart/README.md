# 🛵 SpareKart — Hyperlocal Multi-Vendor Spare Parts Marketplace

> **Stack:** Spring Boot 3.2 · MySQL 8 · React 18 · Vite · JWT · WebSocket (STOMP)

---

## 📁 Project Structure

```
sparekart/
├── database/
│   └── schema.sql              ← Run this first in MySQL
├── backend/                    ← Spring Boot project
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/sparekart/
│       │   ├── SpareKartApplication.java
│       │   ├── config/         ← JWT, Security, WebSocket
│       │   ├── controller/     ← REST controllers
│       │   ├── dto/            ← Request/Response DTOs
│       │   ├── model/          ← JPA Entities
│       │   ├── repository/     ← JPA Repositories (with geo queries)
│       │   └── service/        ← Business logic + OTP
│       └── resources/
│           └── application.properties
└── frontend/                   ← React + Vite project
    ├── package.json
    ├── vite.config.js
    └── src/
        ├── App.jsx             ← Router + Providers
        ├── main.jsx
        ├── styles/globals.css  ← Design system
        ├── context/            ← Auth, Cart, Location
        ├── services/api.js     ← Axios API service
        ├── hooks/useWebSocket.js
        ├── components/
        │   ├── common/         ← Header, Cart, Location modal
        │   └── customer/       ← Product card, detail modal, order confirm
        └── pages/
            ├── auth/           ← Login, Register
            ├── customer/       ← Home, Orders
            └── vendor/         ← Dashboard, Setup, Products
```

---

## 🚀 Setup Instructions

### Step 1 — MySQL Database

```bash
mysql -u root -p
```
```sql
SOURCE /path/to/sparekart/database/schema.sql;
```

### Step 2 — Backend (Spring Boot)

Edit `backend/src/main/resources/application.properties`:
```properties
spring.datasource.password=YOUR_MYSQL_PASSWORD
```

```bash
cd backend
mvn spring-boot:run
```

Backend runs at: **http://localhost:8080**

### Step 3 — Frontend (React)

```bash
cd frontend
npm install
npm run dev
```

Frontend runs at: **http://localhost:3000**

---

## 🔑 API Reference

### Auth
| Method | Endpoint | Body |
|--------|----------|------|
| POST | `/api/auth/register` | `{ name, email, phone, password, role }` |
| POST | `/api/auth/login`    | `{ email, password }` |

### Products (Public)
| Method | Endpoint | Params |
|--------|----------|--------|
| GET | `/api/products` | `lat, lng, categoryId, search` |
| GET | `/api/products/{id}` | `lat, lng` |
| GET | `/api/categories` | — |

### Customer Orders (JWT required)
| Method | Endpoint | Notes |
|--------|----------|-------|
| POST | `/api/orders` | Place order |
| GET  | `/api/orders` | My order history |
| POST | `/api/orders/{id}/verify-otp` | `{ otp }` |

### Vendor (JWT + VENDOR role)
| Method | Endpoint | Notes |
|--------|----------|-------|
| POST  | `/api/vendor/shop` | Register shop |
| GET   | `/api/vendor/shop` | My shop |
| PATCH | `/api/vendor/shop/toggle-open` | Open/close shop |
| POST  | `/api/vendor/products` | Add product listing |
| PUT   | `/api/vendor/products/{id}` | Update price/stock |
| GET   | `/api/vendor/orders` | All orders |
| PATCH | `/api/vendor/orders/{id}/status` | Accept/reject/update |

---

## 👤 Demo Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@sparekart.com | Admin@123 |

---

## 🗺️ Key Features

### Geolocation (Haversine Formula)
- On page load, browser asks for GPS permission
- Products API accepts `?lat=18.52&lng=73.85`
- Backend runs Haversine SQL query to find vendors within 10km
- Products sorted by nearest vendor / lowest price

### Multi-Vendor Display
- When 2+ vendors sell same product → split color bar shown
- All vendors listed with price, distance, ETA, rating
- Customer picks vendor → adds to cart

### Order Flow
```
Customer places order
     ↓
Vendor gets WebSocket push notification
     ↓
Vendor accepts (with ETA) / rejects
     ↓
Customer gets status notification
     ↓
Vendor marks OUT_FOR_DELIVERY
     ↓
Customer sees OTP in app
     ↓
Delivery → Customer shows OTP → Mark DELIVERED
```

### OTP Verification
- 6-digit OTP generated on order placement
- Returned to customer immediately (Phase 2: also SMS via Fast2SMS)
- Vendor/delivery confirms by marking delivered after OTP verification

---

## 📦 Phase 2 Additions (Next Steps)

- [ ] SMS OTP via **Fast2SMS** API (`₹0.15/SMS`)
- [ ] Push notifications via **Firebase FCM**
- [ ] Payment gateway: **Razorpay**
- [ ] Delivery person live GPS tracking
- [ ] Admin dashboard for product/vendor management
- [ ] Ratings & reviews after delivery
- [ ] React Native mobile app for vendors

---

## 🛠️ Tech Stack Details

| Layer | Technology |
|-------|-----------|
| Backend Framework | Spring Boot 3.2 (Java 17) |
| Database | MySQL 8.0 |
| ORM | Spring Data JPA + Hibernate |
| Auth | JWT (jjwt 0.11.5) + Spring Security |
| Real-time | WebSocket (STOMP over SockJS) |
| Frontend | React 18 + Vite |
| Routing | React Router DOM v6 |
| HTTP Client | Axios (with JWT interceptor) |
| Styling | CSS Modules + Custom Design System |
| Notifications | react-hot-toast |
| Date handling | date-fns |
