import styles from './ProductCard.module.css';

export default function ProductCard({ product, onClick, delay = 0 }) {
  const multi = product.vendorCount > 1;

  return (
    <div
      className={styles.card}
      style={{ animationDelay: `${delay}ms` }}
      onClick={() => onClick(product)}
    >
      <div className={styles.imgWrap}>
        <span className={styles.emoji}>{product.emoji}</span>
        <span className={`${styles.vendorBadge} ${multi ? styles.multi : ''}`}>
          {multi ? `${product.vendorCount} vendors` : '1 vendor'}
        </span>
      </div>
      <div className={styles.info}>
        <div className={styles.category}>{product.category?.name}</div>
        <div className={styles.name}>{product.name}</div>
        <div className={styles.desc}>{product.description}</div>
        <div className={styles.bottom}>
          <div>
            <div className={styles.fromLabel}>From</div>
            <div className={styles.price}>₹{Number(product.minPrice).toLocaleString()}</div>
          </div>
          {product.vendors?.[0] && (
            <span className={styles.distBadge}>
              📍 {product.vendors[0].distanceKm} km
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
