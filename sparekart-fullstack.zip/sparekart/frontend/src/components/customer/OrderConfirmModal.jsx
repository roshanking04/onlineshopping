import { CheckCircle, Package, Clock } from 'lucide-react';
import styles from './OrderConfirmModal.module.css';

export default function OrderConfirmModal({ orders, onClose }) {
  if (!orders || orders.length === 0) return null;

  return (
    <div className={styles.overlay}>
      <div className={styles.card}>
        <div className={styles.successIcon}>
          <CheckCircle size={52} color="var(--green)" />
        </div>

        <h2>Order Placed! 🎉</h2>
        <p className={styles.sub}>
          Your order has been sent to the vendor. You'll get a notification once it's accepted.
        </p>

        <div className={styles.ordersList}>
          {orders.map(order => (
            <div key={order.id} className={styles.orderItem}>
              <div className={styles.orderNum}>
                <Package size={14} />
                #{order.orderNumber}
              </div>
              <div className={styles.orderMeta}>
                <span>🏪 {order.vendorShopName}</span>
                <span className="text-accent" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
                  ₹{Number(order.totalAmount).toLocaleString()}
                </span>
              </div>
              {order.estimatedMinutes && (
                <div className={styles.eta}>
                  <Clock size={12} />
                  ETA: ~{order.estimatedMinutes} minutes
                </div>
              )}
            </div>
          ))}
        </div>

        <div className={styles.otpBox}>
          <p className={styles.otpLabel}>🔐 Delivery OTP</p>
          <p className={styles.otpValue}>{orders[0]?.otp || '------'}</p>
          <p className={styles.otpHint}>Show this OTP to the delivery person to confirm receipt</p>
        </div>

        <div className={styles.infoRow}>
          <span>📱 SMS notification sent to your phone</span>
        </div>

        <button className="btn btn-primary btn-lg w-full" style={{ marginTop: 20 }} onClick={onClose}>
          Back to Shopping
        </button>
        <button className="btn btn-ghost w-full" style={{ marginTop: 8 }}
          onClick={() => { onClose(); window.location.href = '/orders'; }}>
          View My Orders →
        </button>
      </div>
    </div>
  );
}
