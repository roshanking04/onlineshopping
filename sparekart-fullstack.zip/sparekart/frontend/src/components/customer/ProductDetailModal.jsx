import { X, Star, MapPin, Clock, ShoppingCart, TrendingDown } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import toast from 'react-hot-toast';
import styles from './ProductDetailModal.module.css';

export default function ProductDetailModal({ product, onClose }) {
  const { addItem, items } = useCart();
  if (!product) return null;

  const vendors = product.vendors || [];
  const sortedVendors = [...vendors].sort((a,b) => a.price - b.price);
  const multiVendor = sortedVendors.length > 1;
  const COLORS = ['#f0a500','#ff6b35','#22c55e','#3b82f6'];

  const isInCart = (vpId) => items.some(i => i.vendorProductId === vpId);

  const handleAdd = (vendor) => {
    if (isInCart(vendor.vendorProductId)) {
      toast('Already in cart!', { icon: '🛒' }); return;
    }
    addItem({
      vendorProductId: vendor.vendorProductId,
      vendorShopId: vendor.vendorShopId,
      shopName: vendor.shopName,
      productId: product.id,
      productName: product.name,
      emoji: product.emoji,
      price: Number(vendor.price),
    });
    toast.success(`Added from ${vendor.shopName}`);
  };

  return (
    <div className={styles.overlay} onClick={e => e.target===e.currentTarget && onClose()}>
      <div className={styles.modal}>
        {/* Header */}
        <div className={styles.modalHeader}>
          <span className={styles.catLabel}>{product.category?.name}</span>
          <button className="btn btn-ghost btn-sm" onClick={onClose}><X size={15}/></button>
        </div>

        {/* Product hero */}
        <div className={styles.hero}>
          <span className={styles.heroEmoji}>{product.emoji}</span>
        </div>
        <div className={styles.heroInfo}>
          <h2 className={styles.productName}>{product.name}</h2>
          <p className={styles.productDesc}>{product.description}</p>
        </div>

        <div className="divider" style={{ margin: '0 24px' }} />

        {/* Vendor section */}
        <div className={styles.vendorSection}>
          <div className={styles.vendorSectionHeader}>
            <h3>Available Vendors</h3>
            {multiVendor && (
              <span className="badge badge-accent">{vendors.length} shops nearby</span>
            )}
          </div>

          {/* Split bar */}
          {multiVendor && (
            <div className={styles.splitBar}>
              {sortedVendors.map((_, i) => (
                <div key={i} className={styles.splitSeg}
                  style={{ flex: 1, background: COLORS[i % COLORS.length] }} />
              ))}
            </div>
          )}

          {sortedVendors.length === 0 ? (
            <div className="empty-state">
              <span className="icon">🏪</span>
              <h3>No vendors nearby</h3>
              <p>Try expanding your search radius</p>
            </div>
          ) : (
            sortedVendors.map((vendor, i) => (
              <div key={vendor.vendorProductId}
                className={`${styles.vendorRow} ${i===0 ? styles.topPick : ''}`}>
                <div className={styles.vendorLeft}>
                  <div className={styles.vendorNameRow}>
                    <span className={styles.vendorName}>{vendor.shopName}</span>
                    {i === 0 && sortedVendors.length > 1 && (
                      <span className={styles.bestBadge}>
                        <TrendingDown size={10}/> BEST PRICE
                      </span>
                    )}
                  </div>
                  <div className={styles.vendorMeta}>
                    <span><Star size={11} fill="currentColor" /> {Number(vendor.rating).toFixed(1)}</span>
                    <span><MapPin size={11} /> {vendor.distanceKm} km</span>
                    <span><Clock size={11} /> {vendor.estimatedDelivery}</span>
                    <span>Stock: {vendor.stock}</span>
                  </div>
                </div>
                <div className={styles.vendorRight}>
                  <div className={styles.mrp}>MRP ₹{Number(vendor.mrp).toLocaleString()}</div>
                  <div className={styles.vendorPrice}>₹{Number(vendor.price).toLocaleString()}</div>
                  <div className={styles.discount}>
                    {Math.round((1 - vendor.price/vendor.mrp)*100)}% off
                  </div>
                  <button
                    className={`btn btn-sm ${isInCart(vendor.vendorProductId) ? 'btn-secondary' : 'btn-primary'}`}
                    style={{ marginTop: 8 }}
                    onClick={() => handleAdd(vendor)}
                  >
                    {isInCart(vendor.vendorProductId)
                      ? '✓ Added'
                      : <><ShoppingCart size={12}/> Add</>
                    }
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
