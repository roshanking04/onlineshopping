import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, MapPin, Bell, LogOut, Store, User, Menu, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { useLocation } from '../../context/LocationContext';
import styles from './Header.module.css';

export default function Header({ onCartOpen, onLocationClick }) {
  const { user, logout } = useAuth();
  const { count } = useCart();
  const { location } = useLocation();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/'); };

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        {/* Logo */}
        <Link to="/" className={styles.logo}>
          Spare<span>Kart</span>
        </Link>

        {/* Location chip */}
        <button className={styles.locationChip} onClick={onLocationClick}>
          <span className={styles.dot} />
          <MapPin size={13} />
          <span className={styles.locLabel}>
            {location ? location.label : 'Set location'}
          </span>
        </button>

        {/* Right actions */}
        <div className={styles.actions}>
          {/* Cart (customers only) */}
          {(!user || user.role === 'CUSTOMER') && (
            <button className={styles.iconBtn} onClick={onCartOpen} aria-label="Cart">
              <ShoppingCart size={19} />
              {count > 0 && <span className={styles.badge}>{count}</span>}
            </button>
          )}

          {/* Authenticated actions */}
          {user ? (
            <>
              {user.role === 'VENDOR' && (
                <Link to="/vendor/dashboard" className="btn btn-secondary btn-sm hide-mobile">
                  <Store size={14} /> Dashboard
                </Link>
              )}
              {user.role === 'CUSTOMER' && (
                <Link to="/orders" className="btn btn-ghost btn-sm hide-mobile">
                  <User size={14} /> My Orders
                </Link>
              )}
              <button className={styles.iconBtn} onClick={handleLogout} title="Logout">
                <LogOut size={17} />
              </button>
            </>
          ) : (
            <>
              <Link to="/login"  className="btn btn-ghost btn-sm hide-mobile">Login</Link>
              <Link to="/register" className="btn btn-primary btn-sm hide-mobile">Sign Up</Link>
            </>
          )}

          {/* Mobile hamburger */}
          <button className={`${styles.iconBtn} hide-desktop`}
            onClick={() => setMenuOpen(o => !o)}>
            {menuOpen ? <X size={19} /> : <Menu size={19} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className={styles.mobileMenu} onClick={() => setMenuOpen(false)}>
          {!user && <>
            <Link to="/login"    className={styles.mobileLink}>Login</Link>
            <Link to="/register" className={styles.mobileLink}>Sign Up</Link>
          </>}
          {user?.role === 'CUSTOMER' && (
            <Link to="/orders" className={styles.mobileLink}>My Orders</Link>
          )}
          {user?.role === 'VENDOR' && (
            <Link to="/vendor/dashboard" className={styles.mobileLink}>Dashboard</Link>
          )}
          {user && (
            <button className={styles.mobileLink} onClick={handleLogout}>Logout</button>
          )}
        </div>
      )}
    </header>
  );
}
