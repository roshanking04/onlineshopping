import { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { useLocation } from '../../context/LocationContext';
import { orderAPI } from '../../services/api';
import toast from 'react-hot-toast';
import styles from './CartPanel.module.css';

export default function CartPanel({ open, onClose, onOrderPlaced }) {
  const { items, removeItem, updateQty, clearCart, total, vendorGroups } = useCart();
  const { user } = useAuth();
  const { location } = useLocation();
  const [loading, setLoading] = useState(false);
  const [address, setAddress] = useState('');
  const [step, setStep] = useState('cart'); // cart | address

  const handleCheckout = () => {
    if (!user) { toast.error('Please login to place order'); return; }
    if (items.length === 0) return;
    setStep('address');
  };

  const handlePlaceOrder = async () => {
    if (!address.trim()) { toast.error('Please enter delivery address'); return; }
    setLoading(true);
    try {
      // Place one order per vendor group
      const orders = [];
      for (const group of vendorGroups) {
        const payload = {
          vendorShopId: group.vendorShopId,
          deliveryAddress: address,
          deliveryLat: location?.lat ?? null,
          deliveryLng: location?.lng ?? null,
          items: group.items.map(i => ({
            vendorProductId: i.vendorProductId,
            quantity: i.quantity
          }))
        };
        const res = await orderAPI.place(payload);
        orders.push(res.data);
      }
      clearCart();
      setStep('cart');
      setAddress('');
      onClose();
      onOrderPlaced(orders);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to place order');
    } finally {
      setLoading(false);
    }
  };

  const deliveryFee = total >= 500 ? 0 : 40;

  return (
    <>
      {/* Backdrop */}
      {open && <div className={styles.backdrop} onClick={onClose} />}

      <aside className={`${styles.panel} ${open ? styles.open : ''}`}>
        {/* Header */}
        <div className={styles.panelHeader}>
          <h2>
            {step === 'cart'
              ? <><ShoppingBag size={18} /> Your Cart</>
              : <>📍 Delivery Details</>
            }
          </h2>
          <button className="btn btn-ghost btn-sm" onClick={onClose}>
            <X size={16} />
          </button>
        </div>

        {/* ── CART STEP ── */}
        {step === 'cart' && (
          <>
            <div className={styles.body}>
              {items.length === 0 ? (
                <div className="empty-state">
                  <span className="icon">🛒</span>
                  <h3>Cart is empty</h3>
                  <p>Add products from the catalogue</p>
                </div>
              ) : (
                vendorGroups.map(group => (
                  <div key={group.vendorShopId} className={styles.vendorGroup}>
                    <div className={styles.vendorLabel}>
                      🏪 {group.shopName}
                    </div>
                    {group.items.map(item => (
                      <div key={item.vendorProductId} className={styles.cartItem}>
                        <span className={styles.itemEmoji}>{item.emoji}</span>
                        <div className={styles.itemInfo}>
                          <div className={styles.itemName}>{item.productName}</div>
                          <div className={styles.itemPrice}>₹{item.price.toLocaleString()}</div>
                        </div>
                        <div className={styles.qtyControl}>
                          <button onClick={() => updateQty(item.vendorProductId, item.quantity - 1)}>
                            <Minus size={12} />
                          </button>
                          <span>{item.quantity}</span>
                          <button onClick={() => updateQty(item.vendorProductId, item.quantity + 1)}>
                            <Plus size={12} />
                          </button>
                        </div>
                        <button className={styles.removeBtn}
                          onClick={() => removeItem(item.vendorProductId)}>
                          <Trash2 size={14} />
                        </button>
                      </div>
                    ))}
                  </div>
                ))
              )}
            </div>

            {items.length > 0 && (
              <div className={styles.footer}>
                <div className={styles.summaryRow}>
                  <span>Subtotal</span>
                  <span>₹{total.toLocaleString()}</span>
                </div>
                <div className={styles.summaryRow}>
                  <span>Delivery</span>
                  <span>{deliveryFee === 0
                    ? <span className="text-green">FREE</span>
                    : `₹${deliveryFee}`
                  }</span>
                </div>
                <div className={`${styles.summaryRow} ${styles.totalRow}`}>
                  <span>Total</span>
                  <span className="text-accent">₹{(total + deliveryFee).toLocaleString()}</span>
                </div>
                {total < 500 && (
                  <p className={styles.freeShipHint}>
                    Add ₹{(500 - total).toLocaleString()} more for free delivery
                  </p>
                )}
                <button className="btn btn-primary btn-lg w-full"
                  style={{ marginTop: 16 }} onClick={handleCheckout}>
                  Proceed to Checkout →
                </button>
              </div>
            )}
          </>
        )}

        {/* ── ADDRESS STEP ── */}
        {step === 'address' && (
          <>
            <div className={styles.body}>
              <div className={styles.orderSummary}>
                <p className={styles.summaryTitle}>Order Summary</p>
                {items.map(i => (
                  <div key={i.vendorProductId} className={styles.summaryItem}>
                    <span>{i.emoji} {i.productName} ×{i.quantity}</span>
                    <span>₹{(i.price * i.quantity).toLocaleString()}</span>
                  </div>
                ))}
                <div className={`${styles.summaryRow} ${styles.totalRow}`} style={{ marginTop: 10 }}>
                  <span>Total</span>
                  <span className="text-accent">₹{(total + deliveryFee).toLocaleString()}</span>
                </div>
              </div>

              <div className="divider" />

              <div className="form-group" style={{ marginTop: 8 }}>
                <label className="form-label">Delivery Address *</label>
                <textarea
                  className="form-input"
                  rows={3}
                  placeholder="House no, street, area, city..."
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  style={{ resize: 'vertical' }}
                />
              </div>

              {location && (
                <p className={styles.locHint}>
                  📍 GPS: {location.lat.toFixed(4)}, {location.lng.toFixed(4)}
                </p>
              )}
            </div>

            <div className={styles.footer}>
              <button className="btn btn-secondary w-full"
                onClick={() => setStep('cart')} disabled={loading}>
                ← Back to Cart
              </button>
              <button className="btn btn-primary btn-lg w-full"
                style={{ marginTop: 10 }}
                onClick={handlePlaceOrder}
                disabled={loading}>
                {loading
                  ? <><span className="spinner" /> Placing Order…</>
                  : '🛵 Place Order'
                }
              </button>
            </div>
          </>
        )}
      </aside>
    </>
  );
}
