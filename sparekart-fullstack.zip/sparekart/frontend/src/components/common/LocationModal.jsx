import { useState } from 'react';
import { MapPin, Navigation } from 'lucide-react';
import { useLocation } from '../../context/LocationContext';
import styles from './LocationModal.module.css';

export default function LocationModal({ onClose }) {
  const { requestLocation } = useLocation();
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');

  const handleAllow = async () => {
    setLoading(true);
    setStatus('Requesting GPS access...');
    try {
      const loc = await requestLocation();
      setStatus(`✅ Located: ${loc.label}`);
      setTimeout(onClose, 700);
    } catch {
      setStatus('Could not get location. Using demo city.');
      setTimeout(onClose, 1000);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.overlay}>
      <div className={styles.card}>
        <div className={styles.glow} />
        <div className={styles.iconWrap}>
          <MapPin size={32} color="var(--accent)" />
        </div>
        <h2>Find Parts Near You</h2>
        <p>
          SpareKart uses your location to show nearby vendor shops,
          compare prices, and calculate fastest delivery times.
        </p>

        <button
          className="btn btn-primary btn-lg w-full"
          onClick={handleAllow}
          disabled={loading}
        >
          {loading
            ? <><span className="spinner" /> Locating…</>
            : <><Navigation size={16} /> Allow Location Access</>
          }
        </button>

        <button
          className="btn btn-ghost w-full"
          style={{ marginTop: 10 }}
          onClick={onClose}
          disabled={loading}
        >
          Skip – Browse all products
        </button>

        {status && <p className={styles.status}>{status}</p>}
      </div>
    </div>
  );
}
