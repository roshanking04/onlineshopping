import { useState, useEffect } from 'react';
import { Package, Clock, CheckCircle, XCircle, Truck } from 'lucide-react';
import { orderAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import styles from './OrdersPage.module.css';

const STATUS_ICONS = {
  PENDING:          <Clock size={15} />,
  ACCEPTED:         <CheckCircle size={15} />,
  PREPARING:        <Package size={15} />,
  OUT_FOR_DELIVERY: <Truck size={15} />,
  DELIVERED:        <CheckCircle size={15} />,
  CANCELLED:        <XCircle size={15} />,
  REJECTED:         <XCircle size={15} />,
};

const STATUS_LABELS = {
  PENDING:          'Pending Acceptance',
  ACCEPTED:         'Accepted',
  PREPARING:        'Preparing Order',
  OUT_FOR_DELIVERY: 'Out for Delivery',
  DELIVERED:        'Delivered',
  CANCELLED:        'Cancelled',
  REJECTED:         'Rejected',
};

export default function OrdersPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    orderAPI.myOrders()
      .then(r => setOrders(r.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [user]);

  if (loading) return (
    <div style={{ display:'flex', justifyContent:'center', padding:'80px' }}>
      <span className="spinner" style={{ width:36, height:36 }} />
    </div>
  );

  return (
    <div className={styles.page}>
      <div className="page-container">
        <div className={styles.pageHeader}>
          <h1>My Orders</h1>
          <span className={styles.count}>{orders.length} orders</span>
        </div>

        {orders.length === 0 ? (
          <div className="empty-state">
            <span className="icon">📦</span>
            <h3>No orders yet</h3>
            <p>Browse products and place your first order</p>
            <button className="btn btn-primary" style={{ marginTop: 16 }}
              onClick={() => navigate('/')}>
              Browse Products
            </button>
          </div>
        ) : (
          <div className={styles.list}>
            {orders.map(order => (
              <div key={order.id}
                className={`${styles.orderCard} ${expanded===order.id ? styles.expanded : ''}`}>

                {/* Summary row */}
                <div className={styles.orderTop}
                  onClick={() => setExpanded(expanded===order.id ? null : order.id)}>

                  <div className={styles.orderLeft}>
                    <div className={styles.orderNum}>#{order.orderNumber}</div>
                    <div className={styles.orderShop}>🏪 {order.vendorShopName}</div>
                    <div className={styles.orderDate}>
                      {order.createdAt
                        ? format(new Date(order.createdAt), 'dd MMM yyyy, hh:mm a')
                        : '—'}
                    </div>
                  </div>

                  <div className={styles.orderRight}>
                    <div className={`${styles.statusBadge} status-${order.status}`}>
                      {STATUS_ICONS[order.status]}
                      {STATUS_LABELS[order.status] || order.status}
                    </div>
                    <div className={styles.orderTotal}>
                      ₹{Number(order.totalAmount).toLocaleString()}
                    </div>
                  </div>
                </div>

                {/* Expanded details */}
                {expanded === order.id && (
                  <div className={styles.orderDetails}>
                    <div className="divider" style={{ margin: '0 0 16px' }} />

                    {/* Items */}
                    <p className={styles.detailLabel}>Items</p>
                    {(order.items || []).map((item, i) => (
                      <div key={i} className={styles.itemRow}>
                        <span>{item.productName} × {item.quantity}</span>
                        <span>₹{Number(item.totalPrice).toLocaleString()}</span>
                      </div>
                    ))}

                    <div className="divider" style={{ margin: '12px 0' }} />

                    {/* Bill */}
                    <div className={styles.billRow}>
                      <span>Subtotal</span>
                      <span>₹{Number(order.subtotal).toLocaleString()}</span>
                    </div>
                    <div className={styles.billRow}>
                      <span>Delivery</span>
                      <span>{Number(order.deliveryFee) === 0
                        ? <span className="text-green">FREE</span>
                        : `₹${Number(order.deliveryFee).toLocaleString()}`}
                      </span>
                    </div>
                    <div className={`${styles.billRow} ${styles.billTotal}`}>
                      <span>Total</span>
                      <span>₹{Number(order.totalAmount).toLocaleString()}</span>
                    </div>

                    {/* Delivery address */}
                    <div className={styles.detailChip}>
                      📍 {order.deliveryAddress}
                    </div>

                    {/* ETA */}
                    {order.estimatedMinutes && order.status === 'ACCEPTED' && (
                      <div className={styles.etaChip}>
                        <Clock size={12} />
                        Estimated: ~{order.estimatedMinutes} minutes
                      </div>
                    )}

                    {/* OTP (only for out_for_delivery) */}
                    {order.status === 'OUT_FOR_DELIVERY' && (
                      <div className={styles.otpChip}>
                        🔐 Your OTP: <strong>{order.otp || 'Check SMS'}</strong>
                        <span>Show to delivery person</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
