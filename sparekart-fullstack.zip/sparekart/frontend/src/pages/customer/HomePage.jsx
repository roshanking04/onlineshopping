import { useState, useEffect, useCallback } from 'react';
import { Search, SlidersHorizontal } from 'lucide-react';
import { productAPI, categoryAPI } from '../../services/api';
import { useLocation } from '../../context/LocationContext';
import ProductCard from '../../components/customer/ProductCard';
import ProductDetailModal from '../../components/customer/ProductDetailModal';
import styles from './HomePage.module.css';

export default function HomePage() {
  const { location } = useLocation();
  const [products, setProducts]       = useState([]);
  const [categories, setCategories]   = useState([]);
  const [loading, setLoading]         = useState(true);
  const [search, setSearch]           = useState('');
  const [activeCat, setActiveCat]     = useState(null);
  const [selectedProduct, setSelected]= useState(null);
  const [searchInput, setSearchInput] = useState('');

  const fetchProducts = useCallback(async (params = {}) => {
    setLoading(true);
    try {
      const res = await productAPI.getAll({
        ...(location ? { lat: location.lat, lng: location.lng } : {}),
        ...params
      });
      setProducts(res.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [location]);

  useEffect(() => {
    categoryAPI.getAll().then(r => setCategories(r.data)).catch(() => {});
  }, []);

  useEffect(() => {
    fetchProducts({ search, categoryId: activeCat });
  }, [location, fetchProducts]);

  const handleSearch = (e) => {
    e.preventDefault();
    setSearch(searchInput);
    setActiveCat(null);
    fetchProducts({ search: searchInput });
  };

  const handleCategory = (id) => {
    const next = id === activeCat ? null : id;
    setActiveCat(next);
    setSearch('');
    setSearchInput('');
    fetchProducts({ categoryId: next });
  };

  const openDetail = async (product) => {
    try {
      const res = await productAPI.getById(product.id, {
        ...(location ? { lat: location.lat, lng: location.lng } : {})
      });
      setSelected(res.data);
    } catch {
      setSelected(product);
    }
  };

  return (
    <div className={styles.page}>
      {/* Hero */}
      <div className={styles.hero}>
        <div className="page-container">
          <div className={styles.heroTag}>
            ⚡ Hyperlocal · Instant · Verified Vendors
          </div>
          <h1 className={styles.heroTitle}>
            Spare Parts,<br />
            <em>Delivered Fast.</em>
          </h1>
          <p className={styles.heroSub}>
            Compare prices across local vendors, order in seconds,
            track delivery door-to-door.
          </p>
        </div>
      </div>

      {/* Search bar */}
      <div className={styles.searchWrap}>
        <div className="page-container">
          <form className={styles.searchBar} onSubmit={handleSearch}>
            <Search size={17} color="var(--muted)" />
            <input
              type="text"
              placeholder="Search batteries, bearings, motors, belts…"
              value={searchInput}
              onChange={e => setSearchInput(e.target.value)}
              className={styles.searchInput}
            />
            <button type="submit" className="btn btn-primary btn-sm">
              Search
            </button>
          </form>
        </div>
      </div>

      {/* Category pills */}
      <div className={styles.catWrap}>
        <div className="page-container">
          <div className={styles.catRow}>
            <button
              className={`${styles.catPill} ${activeCat === null && !search ? styles.active : ''}`}
              onClick={() => handleCategory(null)}
            >
              All
            </button>
            {categories.map(cat => (
              <button
                key={cat.id}
                className={`${styles.catPill} ${activeCat === cat.id ? styles.active : ''}`}
                onClick={() => handleCategory(cat.id)}
              >
                {cat.icon} {cat.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Products grid */}
      <div className={styles.productsSection}>
        <div className="page-container">
          <div className={styles.sectionHeader}>
            <h2>
              {location
                ? '📍 Products Near You'
                : search
                  ? `Search: "${search}"`
                  : 'All Products'
              }
            </h2>
            <span className={styles.count}>
              {loading ? '…' : `${products.length} products`}
            </span>
          </div>

          {loading ? (
            <div className={styles.loadingGrid}>
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className={styles.skeleton} />
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="empty-state">
              <span className="icon">🔍</span>
              <h3>No products found</h3>
              <p>Try a different category or search term</p>
            </div>
          ) : (
            <div className={styles.grid}>
              {products.map((p, i) => (
                <ProductCard
                  key={p.id}
                  product={p}
                  onClick={openDetail}
                  delay={i * 50}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Product detail modal */}
      {selectedProduct && (
        <ProductDetailModal
          product={selectedProduct}
          onClose={() => setSelected(null)}
        />
      )}
    </div>
  );
}
