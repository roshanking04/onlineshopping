import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';
import styles from './AuthPages.module.css';

// ── LOGIN ──────────────────────────────────────────────────
export function LoginPage() {
  const { login } = useAuth();
  const navigate  = useNavigate();
  const [form, setForm]     = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(form.email, form.password);
      toast.success(`Welcome back, ${user.name}!`);
      navigate(user.role === 'VENDOR' ? '/vendor/dashboard' : '/');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <div className={styles.logo}>Spare<span>Kart</span></div>
        <h1 className={styles.title}>Welcome back</h1>
        <p className={styles.sub}>Sign in to your account</p>

        <form className={styles.form} onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Email</label>
            <input
              type="email" className="form-input" required
              placeholder="you@example.com"
              value={form.email}
              onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type="password" className="form-input" required
              placeholder="••••••••"
              value={form.password}
              onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
            />
          </div>

          <button type="submit" className="btn btn-primary btn-lg w-full" disabled={loading}>
            {loading ? <><span className="spinner" /> Signing in…</> : 'Sign In'}
          </button>
        </form>

        <div className={styles.demo}>
          <p>Demo credentials:</p>
          <code>admin@sparekart.com / Admin@123</code>
        </div>

        <p className={styles.switchText}>
          Don't have an account?{' '}
          <Link to="/register" className={styles.link}>Sign up</Link>
        </p>
        <p className={styles.switchText} style={{ marginTop: 4 }}>
          Are you a vendor?{' '}
          <Link to="/register?role=VENDOR" className={styles.link}>Register shop</Link>
        </p>
      </div>
    </div>
  );
}

// ── REGISTER ───────────────────────────────────────────────
export function RegisterPage() {
  const { register } = useAuth();
  const navigate     = useNavigate();
  const params       = new URLSearchParams(window.location.search);
  const defaultRole  = params.get('role') === 'VENDOR' ? 'VENDOR' : 'CUSTOMER';

  const [form, setForm]     = useState({
    name: '', email: '', phone: '', password: '', role: defaultRole
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await register(form);
      toast.success(`Account created! Welcome, ${user.name}`);
      navigate(user.role === 'VENDOR' ? '/vendor/setup' : '/');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <div className={styles.logo}>Spare<span>Kart</span></div>
        <h1 className={styles.title}>Create account</h1>
        <p className={styles.sub}>Join the SpareKart marketplace</p>

        {/* Role toggle */}
        <div className={styles.roleToggle}>
          <button type="button"
            className={`${styles.roleBtn} ${form.role==='CUSTOMER' ? styles.roleActive : ''}`}
            onClick={() => setForm(f => ({ ...f, role: 'CUSTOMER' }))}>
            🛒 Customer
          </button>
          <button type="button"
            className={`${styles.roleBtn} ${form.role==='VENDOR' ? styles.roleActive : ''}`}
            onClick={() => setForm(f => ({ ...f, role: 'VENDOR' }))}>
            🏪 Vendor
          </button>
        </div>

        <form className={styles.form} onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Full Name</label>
            <input type="text" className="form-input" required
              placeholder="Raju Sharma" value={form.name} onChange={set('name')} />
          </div>
          <div className="form-group">
            <label className="form-label">Email</label>
            <input type="email" className="form-input" required
              placeholder="you@example.com" value={form.email} onChange={set('email')} />
          </div>
          <div className="form-group">
            <label className="form-label">Phone (10 digits)</label>
            <input type="tel" className="form-input" required
              placeholder="9876543210" pattern="[6-9]\d{9}"
              value={form.phone} onChange={set('phone')} />
          </div>
          <div className="form-group">
            <label className="form-label">Password (min 6 chars)</label>
            <input type="password" className="form-input" required
              minLength={6} placeholder="••••••••"
              value={form.password} onChange={set('password')} />
          </div>

          <button type="submit" className="btn btn-primary btn-lg w-full" disabled={loading}>
            {loading ? <><span className="spinner" /> Creating account…</> : 'Create Account'}
          </button>
        </form>

        <p className={styles.switchText}>
          Already have an account?{' '}
          <Link to="/login" className={styles.link}>Sign in</Link>
        </p>
      </div>
    </div>
  );
}
