import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' }
});

// Attach JWT token automatically
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Global 401 handler
api.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      localStorage.clear();
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// ── AUTH ────────────────────────────────────────────────────
export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login:    (data) => api.post('/auth/login', data),
};

// ── PRODUCTS ────────────────────────────────────────────────
export const productAPI = {
  getAll:    (params) => api.get('/products', { params }),
  getById:   (id, params) => api.get(`/products/${id}`, { params }),
};

// ── CATEGORIES ──────────────────────────────────────────────
export const categoryAPI = {
  getAll: () => api.get('/categories'),
};

// ── ORDERS ──────────────────────────────────────────────────
export const orderAPI = {
  place:     (data)          => api.post('/orders', data),
  myOrders:  ()              => api.get('/orders'),
  verifyOtp: (id, otp)       => api.post(`/orders/${id}/verify-otp`, { otp }),
};

// ── VENDOR ──────────────────────────────────────────────────
export const vendorAPI = {
  registerShop:   (data)       => api.post('/vendor/shop', data),
  getMyShop:      ()           => api.get('/vendor/shop'),
  toggleOpen:     ()           => api.patch('/vendor/shop/toggle-open'),
  addProduct:     (data)       => api.post('/vendor/products', data),
  updateProduct:  (id, data)   => api.put(`/vendor/products/${id}`, data),
  getOrders:      ()           => api.get('/vendor/orders'),
  updateOrderStatus: (id, data) => api.patch(`/vendor/orders/${id}/status`, data),
};

export default api;
