import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';

import { AuthProvider, useAuth } from './context/AuthContext';
import { LocationProvider } from './context/LocationContext';
import { CartProvider } from './context/CartContext';

import Header from './components/common/Header';
import LocationModal from './components/common/LocationModal';
import CartPanel from './components/common/CartPanel';
import OrderConfirmModal from './components/customer/OrderConfirmModal';

import HomePage from './pages/customer/HomePage';
import OrdersPage from './pages/customer/OrdersPage';
import { LoginPage, RegisterPage } from './pages/auth/AuthPages';
import VendorDashboard from './pages/vendor/VendorDashboard';
import { VendorSetupPage, VendorProductsPage } from './pages/vendor/VendorPages';

import './styles/globals.css';

// Protected route wrapper
function Protected({ children, role }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role && user.role !== 'ADMIN')
    return <Navigate to="/" replace />;
  return children;
}

function AppInner() {
  const [showLocation, setShowLocation] = useState(false);
  const [cartOpen, setCartOpen]         = useState(false);
  const [confirmedOrders, setConfirmed] = useState(null);
  const { user } = useAuth();

  // Show location modal once on first visit
  useEffect(() => {
    const shown = sessionStorage.getItem('locAsked');
    if (!shown) {
      const t = setTimeout(() => {
        setShowLocation(true);
        sessionStorage.setItem('locAsked', '1');
      }, 600);
      return () => clearTimeout(t);
    }
  }, []);

  return (
    <>
      <Header
        onCartOpen={() => setCartOpen(true)}
        onLocationClick={() => setShowLocation(true)}
      />

      {showLocation && (
        <LocationModal onClose={() => setShowLocation(false)} />
      )}

      <CartPanel
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        onOrderPlaced={(orders) => {
          setCartOpen(false);
          setConfirmed(orders);
        }}
      />

      {confirmedOrders && (
        <OrderConfirmModal
          orders={confirmedOrders}
          onClose={() => setConfirmed(null)}
        />
      )}

      <Routes>
        {/* Public */}
        <Route path="/"          element={<HomePage />} />
        <Route path="/login"     element={<LoginPage />} />
        <Route path="/register"  element={<RegisterPage />} />

        {/* Customer */}
        <Route path="/orders" element={
          <Protected><OrdersPage /></Protected>
        } />

        {/* Vendor */}
        <Route path="/vendor/setup" element={
          <Protected role="VENDOR"><VendorSetupPage /></Protected>
        } />
        <Route path="/vendor/dashboard" element={
          <Protected role="VENDOR"><VendorDashboard /></Protected>
        } />
        <Route path="/vendor/products" element={
          <Protected role="VENDOR"><VendorProductsPage /></Protected>
        } />

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>

      <Toaster
        position="bottom-center"
        toastOptions={{
          style: {
            background: 'var(--surface)',
            color: 'var(--text)',
            border: '1px solid var(--border)',
            fontFamily: "'DM Sans', sans-serif",
            fontSize: '14px',
          },
          success: { iconTheme: { primary: 'var(--green)', secondary: '#000' } },
          error:   { iconTheme: { primary: 'var(--red)',   secondary: '#fff' } },
        }}
      />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <LocationProvider>
          <CartProvider>
            <AppInner />
          </CartProvider>
        </LocationProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
