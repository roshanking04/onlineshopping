import { createContext, useContext, useState } from 'react';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [items, setItems] = useState([]); 
  // item: { vendorProductId, vendorShopId, shopName, productId, productName, emoji, price, quantity }

  const addItem = (item) => {
    setItems(prev => {
      const exists = prev.find(i => i.vendorProductId === item.vendorProductId);
      if (exists) return prev.map(i =>
        i.vendorProductId === item.vendorProductId
          ? { ...i, quantity: i.quantity + 1 }
          : i
      );
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const removeItem = (vendorProductId) =>
    setItems(prev => prev.filter(i => i.vendorProductId !== vendorProductId));

  const updateQty = (vendorProductId, qty) => {
    if (qty <= 0) { removeItem(vendorProductId); return; }
    setItems(prev => prev.map(i =>
      i.vendorProductId === vendorProductId ? { ...i, quantity: qty } : i
    ));
  };

  const clearCart = () => setItems([]);

  const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const count = items.reduce((sum, i) => sum + i.quantity, 0);

  // Group items by vendor
  const vendorGroups = items.reduce((acc, item) => {
    const key = item.vendorShopId;
    if (!acc[key]) acc[key] = { vendorShopId: key, shopName: item.shopName, items: [] };
    acc[key].items.push(item);
    return acc;
  }, {});

  return (
    <CartContext.Provider value={{
      items, addItem, removeItem, updateQty, clearCart,
      total, count, vendorGroups: Object.values(vendorGroups)
    }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
