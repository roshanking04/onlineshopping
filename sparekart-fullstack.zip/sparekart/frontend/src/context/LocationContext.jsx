import { createContext, useContext, useState } from 'react';

const LocationContext = createContext(null);

export function LocationProvider({ children }) {
  const [location, setLocation] = useState(null); // { lat, lng, label }

  const requestLocation = () => new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation not supported'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      pos => {
        const loc = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          label: 'Current Location'
        };
        setLocation(loc);
        resolve(loc);
      },
      err => {
        // demo fallback – Pune city centre
        const fallback = { lat: 18.5204, lng: 73.8567, label: 'Pune, MH' };
        setLocation(fallback);
        resolve(fallback);
      },
      { timeout: 8000 }
    );
  });

  const clearLocation = () => setLocation(null);

  return (
    <LocationContext.Provider value={{ location, requestLocation, clearLocation, setLocation }}>
      {children}
    </LocationContext.Provider>
  );
}

export const useLocation = () => useContext(LocationContext);
