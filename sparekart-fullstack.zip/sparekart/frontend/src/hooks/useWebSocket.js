import { useEffect, useRef, useState } from 'react';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { useAuth } from '../context/AuthContext';

export function useWebSocket() {
  const { user } = useAuth();
  const clientRef = useRef(null);
  const [connected, setConnected] = useState(false);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    if (!user) return;

    const client = new Client({
      webSocketFactory: () => new SockJS('/ws'),
      reconnectDelay: 5000,
      onConnect: () => {
        setConnected(true);

        // Customer listens for their order updates
        client.subscribe(`/user/queue/order-updates`, (msg) => {
          const data = JSON.parse(msg.body);
          setNotifications(prev => [{
            id: Date.now(),
            ...data,
            time: new Date()
          }, ...prev]);
        });

        // Vendor listens for new orders
        if (user.role === 'VENDOR') {
          // vendorShopId needs to be fetched after login – can be stored in user context
          client.subscribe(`/topic/vendor/${user.vendorShopId}/new-order`, (msg) => {
            const data = JSON.parse(msg.body);
            setNotifications(prev => [{
              id: Date.now(),
              type: 'NEW_ORDER',
              ...data,
              time: new Date()
            }, ...prev]);
          });
        }
      },
      onDisconnect: () => setConnected(false),
      onStompError: () => setConnected(false)
    });

    client.activate();
    clientRef.current = client;

    return () => { client.deactivate(); };
  }, [user]);

  const clearNotifications = () => setNotifications([]);

  return { connected, notifications, clearNotifications };
}
