-- ============================================================
--  SpareKart – Full Database Schema
--  MySQL 8.0+
-- ============================================================

CREATE DATABASE IF NOT EXISTS sparekart CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sparekart;

-- ── USERS (customers + vendors share this table with role) ──
CREATE TABLE users (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(120)        NOT NULL,
    email       VARCHAR(180)        UNIQUE NOT NULL,
    phone       VARCHAR(15)         UNIQUE NOT NULL,
    password    VARCHAR(255)        NOT NULL,
    role        ENUM('CUSTOMER','VENDOR','ADMIN') NOT NULL DEFAULT 'CUSTOMER',
    is_active   BOOLEAN             NOT NULL DEFAULT TRUE,
    created_at  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ── VENDOR SHOPS ──
CREATE TABLE vendor_shops (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT          NOT NULL UNIQUE,
    shop_name       VARCHAR(180)    NOT NULL,
    address         TEXT            NOT NULL,
    city            VARCHAR(80)     NOT NULL,
    state           VARCHAR(80)     NOT NULL DEFAULT 'Maharashtra',
    pincode         VARCHAR(10)     NOT NULL,
    latitude        DECIMAL(10,7)   NOT NULL,
    longitude       DECIMAL(10,7)   NOT NULL,
    gstin           VARCHAR(20),
    is_open         BOOLEAN         NOT NULL DEFAULT TRUE,
    rating          DECIMAL(3,2)    NOT NULL DEFAULT 0.00,
    total_ratings   INT             NOT NULL DEFAULT 0,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_vs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── PRODUCT CATEGORIES ──
CREATE TABLE categories (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100)    NOT NULL UNIQUE,
    icon        VARCHAR(10)     NOT NULL DEFAULT '📦',
    slug        VARCHAR(100)    NOT NULL UNIQUE,
    is_active   BOOLEAN         NOT NULL DEFAULT TRUE
);

-- ── MASTER PRODUCTS (defined by admin/vendor) ──
CREATE TABLE products (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    category_id     INT             NOT NULL,
    name            VARCHAR(200)    NOT NULL,
    description     TEXT,
    specifications  JSON,
    image_url       VARCHAR(500),
    emoji           VARCHAR(10)     NOT NULL DEFAULT '📦',
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_by      BIGINT          NOT NULL,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_p_cat  FOREIGN KEY (category_id) REFERENCES categories(id),
    CONSTRAINT fk_p_user FOREIGN KEY (created_by)  REFERENCES users(id)
);

-- ── VENDOR PRODUCT LISTINGS (price per vendor) ──
CREATE TABLE vendor_products (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    vendor_shop_id  BIGINT          NOT NULL,
    product_id      BIGINT          NOT NULL,
    price           DECIMAL(10,2)   NOT NULL,
    mrp             DECIMAL(10,2)   NOT NULL,
    stock           INT             NOT NULL DEFAULT 0,
    is_available    BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_vp_shop    FOREIGN KEY (vendor_shop_id) REFERENCES vendor_shops(id) ON DELETE CASCADE,
    CONSTRAINT fk_vp_product FOREIGN KEY (product_id)     REFERENCES products(id)     ON DELETE CASCADE,
    UNIQUE KEY uq_vendor_product (vendor_shop_id, product_id)
);

-- ── CUSTOMER ADDRESSES ──
CREATE TABLE customer_addresses (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT          NOT NULL,
    label       VARCHAR(50)     NOT NULL DEFAULT 'Home',
    address     TEXT            NOT NULL,
    city        VARCHAR(80)     NOT NULL,
    pincode     VARCHAR(10)     NOT NULL,
    latitude    DECIMAL(10,7),
    longitude   DECIMAL(10,7),
    is_default  BOOLEAN         NOT NULL DEFAULT FALSE,
    CONSTRAINT fk_ca_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── ORDERS ──
CREATE TABLE orders (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_number    VARCHAR(20)     NOT NULL UNIQUE,
    customer_id     BIGINT          NOT NULL,
    vendor_shop_id  BIGINT          NOT NULL,
    address_id      BIGINT,
    delivery_lat    DECIMAL(10,7),
    delivery_lng    DECIMAL(10,7),
    delivery_address TEXT           NOT NULL,
    subtotal        DECIMAL(10,2)   NOT NULL,
    delivery_fee    DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    total_amount    DECIMAL(10,2)   NOT NULL,
    status          ENUM('PENDING','ACCEPTED','PREPARING','OUT_FOR_DELIVERY','DELIVERED','CANCELLED','REJECTED') NOT NULL DEFAULT 'PENDING',
    otp             VARCHAR(6),
    otp_verified    BOOLEAN         NOT NULL DEFAULT FALSE,
    delivery_person_id BIGINT,
    estimated_minutes  INT,
    accepted_at     DATETIME,
    delivered_at    DATETIME,
    cancelled_at    DATETIME,
    cancel_reason   VARCHAR(255),
    notes           TEXT,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_o_customer FOREIGN KEY (customer_id)    REFERENCES users(id),
    CONSTRAINT fk_o_vendor   FOREIGN KEY (vendor_shop_id) REFERENCES vendor_shops(id),
    CONSTRAINT fk_o_delivery FOREIGN KEY (delivery_person_id) REFERENCES users(id)
);

-- ── ORDER ITEMS ──
CREATE TABLE order_items (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id            BIGINT          NOT NULL,
    vendor_product_id   BIGINT          NOT NULL,
    product_id          BIGINT          NOT NULL,
    product_name        VARCHAR(200)    NOT NULL,
    quantity            INT             NOT NULL DEFAULT 1,
    unit_price          DECIMAL(10,2)   NOT NULL,
    total_price         DECIMAL(10,2)   NOT NULL,
    CONSTRAINT fk_oi_order   FOREIGN KEY (order_id)   REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_oi_vp      FOREIGN KEY (vendor_product_id) REFERENCES vendor_products(id),
    CONSTRAINT fk_oi_product FOREIGN KEY (product_id) REFERENCES products(id)
);

-- ── DELIVERY PERSONS ──
CREATE TABLE delivery_persons (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT          NOT NULL UNIQUE,
    vendor_shop_id  BIGINT          NOT NULL,
    vehicle_number  VARCHAR(20),
    is_available    BOOLEAN         NOT NULL DEFAULT TRUE,
    current_lat     DECIMAL(10,7),
    current_lng     DECIMAL(10,7),
    CONSTRAINT fk_dp_user  FOREIGN KEY (user_id)        REFERENCES users(id),
    CONSTRAINT fk_dp_shop  FOREIGN KEY (vendor_shop_id) REFERENCES vendor_shops(id)
);

-- ── NOTIFICATIONS ──
CREATE TABLE notifications (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT          NOT NULL,
    title       VARCHAR(200)    NOT NULL,
    message     TEXT            NOT NULL,
    type        ENUM('ORDER_PLACED','ORDER_ACCEPTED','ORDER_REJECTED','OUT_FOR_DELIVERY','DELIVERED','OTP','GENERAL') NOT NULL,
    is_read     BOOLEAN         NOT NULL DEFAULT FALSE,
    order_id    BIGINT,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_n_user  FOREIGN KEY (user_id)  REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_n_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
);

-- ── RATINGS ──
CREATE TABLE ratings (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id    BIGINT          NOT NULL UNIQUE,
    customer_id BIGINT          NOT NULL,
    vendor_id   BIGINT          NOT NULL,
    rating      TINYINT         NOT NULL CHECK (rating BETWEEN 1 AND 5),
    review      TEXT,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_r_order    FOREIGN KEY (order_id)    REFERENCES orders(id),
    CONSTRAINT fk_r_customer FOREIGN KEY (customer_id) REFERENCES users(id),
    CONSTRAINT fk_r_vendor   FOREIGN KEY (vendor_id)   REFERENCES vendor_shops(id)
);

-- ── SEED: CATEGORIES ──
INSERT INTO categories (name, icon, slug) VALUES
('Batteries',     '🔋', 'batteries'),
('Bearings',      '⚙️', 'bearings'),
('Electrical',    '⚡', 'electrical'),
('Belts & Drives','🔗', 'belts-drives'),
('Motors',        '🔌', 'motors'),
('Fasteners',     '🔩', 'fasteners'),
('Seals & Gaskets','🛞','seals-gaskets'),
('Pumps',         '💧', 'pumps'),
('Filters',       '🔘', 'filters'),
('Tools',         '🔧', 'tools');

-- ── SEED: ADMIN USER ──
-- password: Admin@123 (BCrypt)
INSERT INTO users (name, email, phone, password, role) VALUES
('Admin SpareKart', 'admin@sparekart.com', '9000000000',
 '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'ADMIN');

-- ── INDEXES ──
CREATE INDEX idx_vendor_products_location ON vendor_shops(latitude, longitude);
CREATE INDEX idx_orders_customer    ON orders(customer_id);
CREATE INDEX idx_orders_vendor      ON orders(vendor_shop_id);
CREATE INDEX idx_orders_status      ON orders(status);
CREATE INDEX idx_notifications_user ON notifications(user_id, is_read);
CREATE FULLTEXT INDEX idx_products_search ON products(name, description);
