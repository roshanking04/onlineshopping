package com.sparekart.repository;

import com.sparekart.model.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    Optional<User> findByPhone(String phone);
    boolean existsByEmail(String email);
    boolean existsByPhone(String phone);
}

@Repository
interface VendorShopRepository extends JpaRepository<VendorShop, Long> {
    Optional<VendorShop> findByUserId(Long userId);

    // Haversine formula – find vendors within X km
    @Query(value = """
        SELECT vs.*, (
            6371 * ACOS(
                COS(RADIANS(:lat)) * COS(RADIANS(vs.latitude))
                * COS(RADIANS(vs.longitude) - RADIANS(:lng))
                + SIN(RADIANS(:lat)) * SIN(RADIANS(vs.latitude))
            )
        ) AS distance
        FROM vendor_shops vs
        WHERE vs.is_open = true
        HAVING distance <= :radiusKm
        ORDER BY distance ASC
        """, nativeQuery = true)
    List<VendorShop> findNearbyVendors(
            @Param("lat") double lat,
            @Param("lng") double lng,
            @Param("radiusKm") double radiusKm);
}

@Repository
interface CategoryRepository extends JpaRepository<Category, Integer> {
    List<Category> findByActiveTrue();
}

@Repository
interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByActiveTrueOrderByName();
    List<Product> findByCategoryIdAndActiveTrue(Integer categoryId);

    @Query("SELECT p FROM Product p WHERE p.active = true AND " +
           "(LOWER(p.name) LIKE LOWER(CONCAT('%',:q,'%')) OR " +
           "LOWER(p.description) LIKE LOWER(CONCAT('%',:q,'%')))")
    List<Product> searchProducts(@Param("q") String query);
}

@Repository
interface VendorProductRepository extends JpaRepository<VendorProduct, Long> {
    List<VendorProduct> findByVendorShopId(Long vendorShopId);
    List<VendorProduct> findByProductIdAndAvailableTrue(Long productId);

    @Query("SELECT vp FROM VendorProduct vp WHERE vp.product.id = :productId " +
           "AND vp.available = true AND vp.stock > 0 AND vp.vendorShop.open = true " +
           "ORDER BY vp.price ASC")
    List<VendorProduct> findAvailableByProduct(@Param("productId") Long productId);

    // find vendors for a product within radius
    @Query(value = """
        SELECT vp.* FROM vendor_products vp
        JOIN vendor_shops vs ON vp.vendor_shop_id = vs.id
        WHERE vp.product_id = :productId
        AND vp.is_available = true
        AND vp.stock > 0
        AND vs.is_open = true
        AND (6371 * ACOS(
            COS(RADIANS(:lat)) * COS(RADIANS(vs.latitude))
            * COS(RADIANS(vs.longitude) - RADIANS(:lng))
            + SIN(RADIANS(:lat)) * SIN(RADIANS(vs.latitude))
        )) <= :radiusKm
        ORDER BY vp.price ASC
        """, nativeQuery = true)
    List<VendorProduct> findNearbyVendorsByProduct(
            @Param("productId") Long productId,
            @Param("lat") double lat,
            @Param("lng") double lng,
            @Param("radiusKm") double radiusKm);

    Optional<VendorProduct> findByVendorShopIdAndProductId(Long vendorShopId, Long productId);
}

@Repository
interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByCustomerIdOrderByCreatedAtDesc(Long customerId);
    List<Order> findByVendorShopIdOrderByCreatedAtDesc(Long vendorShopId);
    List<Order> findByVendorShopIdAndStatusOrderByCreatedAtDesc(Long vendorShopId, Order.OrderStatus status);
    Optional<Order> findByOrderNumber(String orderNumber);
}

@Repository
interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByUserIdOrderByCreatedAtDesc(Long userId);
    List<Notification> findByUserIdAndReadFalseOrderByCreatedAtDesc(Long userId);
    long countByUserIdAndReadFalse(Long userId);
}
