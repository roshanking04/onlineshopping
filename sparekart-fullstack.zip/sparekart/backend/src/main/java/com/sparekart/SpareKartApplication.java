package com.sparekart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpareKartApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpareKartApplication.class, args);
    }
}
