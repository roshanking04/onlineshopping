package com.sparekart.service;

import com.sparekart.dto.OrderDTOs.*;
import com.sparekart.model.*;
import com.sparekart.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final VendorProductRepository vendorProductRepository;
    private final UserRepository userRepository;
    private final VendorShopRepository vendorShopRepository;
    private final NotificationRepository notificationRepository;
    private final SimpMessagingTemplate messagingTemplate;

    @Transactional
    public OrderResponse placeOrder(Long customerId, PlaceOrderRequest req) {
        User customer = userRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        VendorShop shop = vendorShopRepository.findById(req.getVendorShopId())
                .orElseThrow(() -> new RuntimeException("Vendor not found"));

        // Build order items
        List<OrderItem> items = new ArrayList<>();
        BigDecimal subtotal = BigDecimal.ZERO;

        for (OrderItemRequest itemReq : req.getItems()) {
            VendorProduct vp = vendorProductRepository.findById(itemReq.getVendorProductId())
                    .orElseThrow(() -> new RuntimeException("Product not found: " + itemReq.getVendorProductId()));

            if (vp.getStock() < itemReq.getQuantity())
                throw new RuntimeException("Insufficient stock for: " + vp.getProduct().getName());

            BigDecimal lineTotal = vp.getPrice().multiply(BigDecimal.valueOf(itemReq.getQuantity()));
            subtotal = subtotal.add(lineTotal);

            items.add(OrderItem.builder()
                    .vendorProductId(vp.getId())
                    .productId(vp.getProduct().getId())
                    .productName(vp.getProduct().getName())
                    .quantity(itemReq.getQuantity())
                    .unitPrice(vp.getPrice())
                    .totalPrice(lineTotal)
                    .build());

            // Decrease stock
            vp.setStock(vp.getStock() - itemReq.getQuantity());
            vendorProductRepository.save(vp);
        }

        BigDecimal deliveryFee = subtotal.compareTo(BigDecimal.valueOf(500)) >= 0
                ? BigDecimal.ZERO : BigDecimal.valueOf(40);
        BigDecimal total = subtotal.add(deliveryFee);

        String otp = String.format("%06d", new SecureRandom().nextInt(999999));
        String orderNumber = "SKT" + DateTimeFormatter.ofPattern("yyyyMMddHHmmss")
                .format(LocalDateTime.now()) + new SecureRandom().nextInt(100);

        Order order = Order.builder()
                .orderNumber(orderNumber)
                .customer(customer)
                .vendorShop(shop)
                .deliveryAddress(req.getDeliveryAddress())
                .deliveryLat(req.getDeliveryLat())
                .deliveryLng(req.getDeliveryLng())
                .subtotal(subtotal)
                .deliveryFee(deliveryFee)
                .totalAmount(total)
                .status(Order.OrderStatus.PENDING)
                .otp(otp)
                .notes(req.getNotes())
                .build();

        Order saved = orderRepository.save(order);
        items.forEach(i -> i.setOrder(saved));
        saved.setItems(items);
        orderRepository.save(saved);

        // Notify customer
        saveNotification(customer, "Order Placed! 🎉",
                "Your order #" + orderNumber + " has been sent to " + shop.getShopName(),
                Notification.NotificationType.ORDER_PLACED, saved.getId());

        // Notify vendor via WebSocket
        messagingTemplate.convertAndSend(
                "/topic/vendor/" + shop.getId() + "/new-order",
                Map.of("orderId", saved.getId(), "orderNumber", orderNumber,
                       "total", total, "customerName", customer.getName()));

        return toOrderResponse(saved, otp);
    }

    @Transactional
    public OrderResponse updateStatus(Long orderId, Long vendorUserId, UpdateOrderStatusRequest req) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        VendorShop shop = vendorShopRepository.findByUserId(vendorUserId)
                .orElseThrow(() -> new RuntimeException("Vendor shop not found"));

        if (!order.getVendorShop().getId().equals(shop.getId()))
            throw new RuntimeException("Unauthorized");

        order.setStatus(req.getStatus());

        if (req.getStatus() == Order.OrderStatus.ACCEPTED) {
            order.setAcceptedAt(LocalDateTime.now());
            order.setEstimatedMinutes(req.getEstimatedMinutes() != null ? req.getEstimatedMinutes() : 30);
            saveNotification(order.getCustomer(), "Order Accepted ✅",
                    shop.getShopName() + " accepted your order! ETA: " + order.getEstimatedMinutes() + " mins",
                    Notification.NotificationType.ORDER_ACCEPTED, orderId);
        } else if (req.getStatus() == Order.OrderStatus.REJECTED) {
            order.setCancelReason(req.getCancelReason());
            order.setCancelledAt(LocalDateTime.now());
            saveNotification(order.getCustomer(), "Order Rejected ❌",
                    "Sorry, " + shop.getShopName() + " could not accept your order. Reason: " + req.getCancelReason(),
                    Notification.NotificationType.ORDER_REJECTED, orderId);
        } else if (req.getStatus() == Order.OrderStatus.OUT_FOR_DELIVERY) {
            saveNotification(order.getCustomer(), "Out for Delivery 🚴",
                    "Your order is on the way! Show OTP " + order.getOtp() + " to the delivery person.",
                    Notification.NotificationType.OUT_FOR_DELIVERY, orderId);
        } else if (req.getStatus() == Order.OrderStatus.DELIVERED) {
            order.setDeliveredAt(LocalDateTime.now());
            order.setOtpVerified(true);
            saveNotification(order.getCustomer(), "Delivered! 🎊",
                    "Your order has been delivered. Thank you for using SpareKart!",
                    Notification.NotificationType.DELIVERED, orderId);
        }

        Order updated = orderRepository.save(order);

        // WebSocket push to customer
        messagingTemplate.convertAndSendToUser(
                order.getCustomer().getEmail(),
                "/queue/order-updates",
                Map.of("orderId", orderId, "status", req.getStatus().name()));

        return toOrderResponse(updated, null);
    }

    public boolean verifyOtp(Long orderId, Long customerId, String otp) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        if (!order.getCustomer().getId().equals(customerId))
            throw new RuntimeException("Unauthorized");
        if (order.getOtp().equals(otp)) {
            order.setOtpVerified(true);
            order.setStatus(Order.OrderStatus.DELIVERED);
            order.setDeliveredAt(LocalDateTime.now());
            orderRepository.save(order);
            return true;
        }
        return false;
    }

    public List<OrderResponse> getCustomerOrders(Long customerId) {
        return orderRepository.findByCustomerIdOrderByCreatedAtDesc(customerId)
                .stream().map(o -> toOrderResponse(o, null)).collect(Collectors.toList());
    }

    public List<OrderResponse> getVendorOrders(Long vendorUserId) {
        VendorShop shop = vendorShopRepository.findByUserId(vendorUserId)
                .orElseThrow(() -> new RuntimeException("Vendor shop not found"));
        return orderRepository.findByVendorShopIdOrderByCreatedAtDesc(shop.getId())
                .stream().map(o -> toOrderResponse(o, null)).collect(Collectors.toList());
    }

    private void saveNotification(User user, String title, String message,
                                   Notification.NotificationType type, Long orderId) {
        notificationRepository.save(Notification.builder()
                .user(user).title(title).message(message).type(type).orderId(orderId).build());
    }

    private OrderResponse toOrderResponse(Order order, String otp) {
        List<OrderResponse.OrderItemResponse> itemResponses = order.getItems() == null
                ? List.of()
                : order.getItems().stream().map(i -> OrderResponse.OrderItemResponse.builder()
                        .productId(i.getProductId())
                        .productName(i.getProductName())
                        .quantity(i.getQuantity())
                        .unitPrice(i.getUnitPrice())
                        .totalPrice(i.getTotalPrice())
                        .build()).collect(Collectors.toList());

        return OrderResponse.builder()
                .id(order.getId())
                .orderNumber(order.getOrderNumber())
                .status(order.getStatus().name())
                .subtotal(order.getSubtotal())
                .deliveryFee(order.getDeliveryFee())
                .totalAmount(order.getTotalAmount())
                .vendorShopName(order.getVendorShop().getShopName())
                .deliveryAddress(order.getDeliveryAddress())
                .estimatedMinutes(order.getEstimatedMinutes())
                .otp(otp) // only returned when order is first placed
                .items(itemResponses)
                .createdAt(order.getCreatedAt())
                .build();
    }
}
