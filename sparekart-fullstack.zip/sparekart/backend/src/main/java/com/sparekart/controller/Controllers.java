package com.sparekart.controller;

import com.sparekart.dto.*;
import com.sparekart.service.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import com.sparekart.repository.UserRepository;

import java.util.List;
import java.util.Map;

// ── AUTH CONTROLLER ────────────────────────────────────────
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<AuthDTOs.AuthResponse> register(@Valid @RequestBody AuthDTOs.RegisterRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(authService.register(req));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthDTOs.AuthResponse> login(@Valid @RequestBody AuthDTOs.LoginRequest req) {
        return ResponseEntity.ok(authService.login(req));
    }
}

// ── PRODUCT CONTROLLER ─────────────────────────────────────
@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
class ProductController {

    private final ProductService productService;

    @GetMapping
    public ResponseEntity<List<ProductDTOs.ProductResponse>> getProducts(
            @RequestParam(required = false) Double lat,
            @RequestParam(required = false) Double lng,
            @RequestParam(required = false) Integer categoryId,
            @RequestParam(required = false) String search) {
        return ResponseEntity.ok(productService.getAllProducts(lat, lng, categoryId, search));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductDTOs.ProductResponse> getProduct(
            @PathVariable Long id,
            @RequestParam(required = false) Double lat,
            @RequestParam(required = false) Double lng) {
        return ResponseEntity.ok(productService.getProductById(id, lat, lng));
    }
}

// ── CATEGORY CONTROLLER ────────────────────────────────────
@RestController
@RequestMapping("/api/categories")
@RequiredArgsConstructor
class CategoryController {
    private final ProductService productService;

    @GetMapping
    public ResponseEntity<List<ProductDTOs.CategoryDTO>> getCategories() {
        return ResponseEntity.ok(productService.getAllCategories());
    }
}

// ── VENDOR CONTROLLER ──────────────────────────────────────
@RestController
@RequestMapping("/api/vendor")
@RequiredArgsConstructor
@PreAuthorize("hasRole('VENDOR') or hasRole('ADMIN')")
class VendorController {

    private final ProductService productService;
    private final OrderService orderService;
    private final VendorService vendorService;
    private final UserRepository userRepository;

    private Long getUserId(UserDetails ud) {
        return userRepository.findByEmail(ud.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found")).getId();
    }

    @PostMapping("/shop")
    public ResponseEntity<?> registerShop(
            @AuthenticationPrincipal UserDetails ud,
            @Valid @RequestBody VendorDTOs.ShopRegisterRequest req) {
        return ResponseEntity.ok(vendorService.registerShop(getUserId(ud), req));
    }

    @GetMapping("/shop")
    public ResponseEntity<?> getMyShop(@AuthenticationPrincipal UserDetails ud) {
        return ResponseEntity.ok(vendorService.getMyShop(getUserId(ud)));
    }

    @PatchMapping("/shop/toggle-open")
    public ResponseEntity<?> toggleOpen(@AuthenticationPrincipal UserDetails ud) {
        return ResponseEntity.ok(vendorService.toggleShopOpen(getUserId(ud)));
    }

    @PostMapping("/products")
    public ResponseEntity<?> addProduct(
            @AuthenticationPrincipal UserDetails ud,
            @Valid @RequestBody ProductDTOs.VendorAddProductRequest req) {
        productService.addVendorProduct(getUserId(ud), req);
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("message", "Product listing added"));
    }

    @PutMapping("/products/{vpId}")
    public ResponseEntity<?> updateProduct(
            @PathVariable Long vpId,
            @AuthenticationPrincipal UserDetails ud,
            @Valid @RequestBody ProductDTOs.VendorAddProductRequest req) {
        productService.updateVendorProduct(vpId, getUserId(ud), req);
        return ResponseEntity.ok(Map.of("message", "Updated"));
    }

    @GetMapping("/orders")
    public ResponseEntity<List<OrderDTOs.OrderResponse>> getOrders(@AuthenticationPrincipal UserDetails ud) {
        return ResponseEntity.ok(orderService.getVendorOrders(getUserId(ud)));
    }

    @PatchMapping("/orders/{orderId}/status")
    public ResponseEntity<OrderDTOs.OrderResponse> updateOrderStatus(
            @PathVariable Long orderId,
            @AuthenticationPrincipal UserDetails ud,
            @Valid @RequestBody OrderDTOs.UpdateOrderStatusRequest req) {
        return ResponseEntity.ok(orderService.updateStatus(orderId, getUserId(ud), req));
    }
}

// ── CUSTOMER ORDER CONTROLLER ──────────────────────────────
@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
class OrderController {

    private final OrderService orderService;
    private final UserRepository userRepository;

    private Long getUserId(UserDetails ud) {
        return userRepository.findByEmail(ud.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found")).getId();
    }

    @PostMapping
    public ResponseEntity<OrderDTOs.OrderResponse> placeOrder(
            @AuthenticationPrincipal UserDetails ud,
            @Valid @RequestBody OrderDTOs.PlaceOrderRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(orderService.placeOrder(getUserId(ud), req));
    }

    @GetMapping
    public ResponseEntity<List<OrderDTOs.OrderResponse>> myOrders(@AuthenticationPrincipal UserDetails ud) {
        return ResponseEntity.ok(orderService.getCustomerOrders(getUserId(ud)));
    }

    @PostMapping("/{orderId}/verify-otp")
    public ResponseEntity<?> verifyOtp(
            @PathVariable Long orderId,
            @AuthenticationPrincipal UserDetails ud,
            @RequestBody OrderDTOs.VerifyOtpRequest req) {
        boolean ok = orderService.verifyOtp(orderId, getUserId(ud), req.getOtp());
        return ok ? ResponseEntity.ok(Map.of("message", "OTP verified, order marked delivered"))
                  : ResponseEntity.badRequest().body(Map.of("error", "Invalid OTP"));
    }
}

// ── GLOBAL EXCEPTION HANDLER ──────────────────────────────
@RestControllerAdvice
class GlobalExceptionHandler {

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Map<String,String>> handleRuntime(RuntimeException ex) {
        return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
    }

    @ExceptionHandler(org.springframework.security.access.AccessDeniedException.class)
    public ResponseEntity<Map<String,String>> handleAccess(Exception ex) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", "Access denied"));
    }
}
