package com.sparekart.service;

import com.sparekart.dto.VendorDTOs.*;
import com.sparekart.model.*;
import com.sparekart.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class VendorService {

    private final VendorShopRepository vendorShopRepository;
    private final UserRepository userRepository;

    public ShopResponse registerShop(Long userId, ShopRegisterRequest req) {
        if (vendorShopRepository.findByUserId(userId).isPresent())
            throw new RuntimeException("Shop already registered for this account");

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        VendorShop shop = VendorShop.builder()
                .user(user)
                .shopName(req.getShopName())
                .address(req.getAddress())
                .city(req.getCity())
                .state(req.getState())
                .pincode(req.getPincode())
                .latitude(req.getLatitude())
                .longitude(req.getLongitude())
                .gstin(req.getGstin())
                .open(true)
                .build();

        VendorShop saved = vendorShopRepository.save(shop);
        return toShopResponse(saved, 0);
    }

    public ShopResponse getMyShop(Long userId) {
        VendorShop shop = vendorShopRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("No shop registered"));
        return toShopResponse(shop, 0);
    }

    public ShopResponse toggleShopOpen(Long userId) {
        VendorShop shop = vendorShopRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("No shop registered"));
        shop.setOpen(!shop.isOpen());
        return toShopResponse(vendorShopRepository.save(shop), 0);
    }

    private ShopResponse toShopResponse(VendorShop s, double dist) {
        return ShopResponse.builder()
                .id(s.getId())
                .shopName(s.getShopName())
                .address(s.getAddress())
                .city(s.getCity())
                .pincode(s.getPincode())
                .latitude(s.getLatitude())
                .longitude(s.getLongitude())
                .open(s.isOpen())
                .rating(s.getRating())
                .totalRatings(s.getTotalRatings())
                .distanceKm(dist)
                .build();
    }
}
