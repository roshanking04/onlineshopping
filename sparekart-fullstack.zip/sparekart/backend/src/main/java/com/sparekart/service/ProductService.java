package com.sparekart.service;

import com.sparekart.dto.ProductDTOs.*;
import com.sparekart.model.*;
import com.sparekart.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;
    private final VendorProductRepository vendorProductRepository;
    private final CategoryRepository categoryRepository;
    private final VendorShopRepository vendorShopRepository;

    private static final double DEFAULT_RADIUS_KM = 10.0;

    public List<CategoryDTO> getAllCategories() {
        return categoryRepository.findByActiveTrue().stream()
                .map(c -> CategoryDTO.builder()
                        .id(c.getId()).name(c.getName())
                        .icon(c.getIcon()).slug(c.getSlug())
                        .build())
                .collect(Collectors.toList());
    }

    public List<ProductResponse> getAllProducts(Double lat, Double lng, Integer categoryId, String search) {
        List<Product> products;

        if (search != null && !search.isBlank()) {
            products = productRepository.searchProducts(search.trim());
        } else if (categoryId != null) {
            products = productRepository.findByCategoryIdAndActiveTrue(categoryId);
        } else {
            products = productRepository.findByActiveTrueOrderByName();
        }

        return products.stream()
                .map(p -> toProductResponse(p, lat, lng))
                .filter(pr -> pr.getVendorCount() > 0)
                .sorted(Comparator.comparing(ProductResponse::getMinPrice))
                .collect(Collectors.toList());
    }

    public ProductResponse getProductById(Long id, Double lat, Double lng) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        return toProductResponse(product, lat, lng);
    }

    private ProductResponse toProductResponse(Product p, Double lat, Double lng) {
        List<VendorProduct> vendorProducts;

        if (lat != null && lng != null) {
            vendorProducts = vendorProductRepository.findNearbyVendorsByProduct(
                    p.getId(), lat, lng, DEFAULT_RADIUS_KM);
        } else {
            vendorProducts = vendorProductRepository.findAvailableByProduct(p.getId());
        }

        // If 2 vendors: split 50/50 display (both shown equally)
        // Already sorted by price from DB

        List<VendorProductDTO> vendorDTOs = vendorProducts.stream()
                .map(vp -> {
                    double dist = (lat != null && lng != null)
                            ? calculateDistance(lat, lng,
                                vp.getVendorShop().getLatitude().doubleValue(),
                                vp.getVendorShop().getLongitude().doubleValue())
                            : 0;
                    return VendorProductDTO.builder()
                            .vendorProductId(vp.getId())
                            .vendorShopId(vp.getVendorShop().getId())
                            .shopName(vp.getVendorShop().getShopName())
                            .shopAddress(vp.getVendorShop().getAddress())
                            .price(vp.getPrice())
                            .mrp(vp.getMrp())
                            .stock(vp.getStock())
                            .rating(vp.getVendorShop().getRating())
                            .distanceKm(BigDecimal.valueOf(dist)
                                    .setScale(1, RoundingMode.HALF_UP).doubleValue())
                            .estimatedDelivery(estimateDelivery(dist))
                            .build();
                })
                .collect(Collectors.toList());

        BigDecimal minPrice = vendorDTOs.isEmpty() ? BigDecimal.ZERO
                : vendorDTOs.stream().map(VendorProductDTO::getPrice)
                        .min(Comparator.naturalOrder()).orElse(BigDecimal.ZERO);

        return ProductResponse.builder()
                .id(p.getId())
                .name(p.getName())
                .description(p.getDescription())
                .emoji(p.getEmoji())
                .imageUrl(p.getImageUrl())
                .category(CategoryDTO.builder()
                        .id(p.getCategory().getId())
                        .name(p.getCategory().getName())
                        .icon(p.getCategory().getIcon())
                        .slug(p.getCategory().getSlug())
                        .build())
                .vendors(vendorDTOs)
                .minPrice(minPrice)
                .vendorCount(vendorDTOs.size())
                .build();
    }

    // Haversine distance in km
    private double calculateDistance(double lat1, double lng1, double lat2, double lng2) {
        final double R = 6371;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dLat/2)*Math.sin(dLat/2)
                 + Math.cos(Math.toRadians(lat1))*Math.cos(Math.toRadians(lat2))
                 * Math.sin(dLng/2)*Math.sin(dLng/2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }

    private String estimateDelivery(double distKm) {
        if (distKm <= 1) return "15–20 min";
        if (distKm <= 3) return "25–35 min";
        if (distKm <= 6) return "40–55 min";
        return "1–2 hrs";
    }

    // Vendor adds a product listing
    public void addVendorProduct(Long vendorUserId, com.sparekart.dto.ProductDTOs.VendorAddProductRequest req) {
        VendorShop shop = vendorShopRepository.findByUserId(vendorUserId)
                .orElseThrow(() -> new RuntimeException("Vendor shop not found"));
        Product product = productRepository.findById(req.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        VendorProduct vp = VendorProduct.builder()
                .vendorShop(shop)
                .product(product)
                .price(req.getPrice())
                .mrp(req.getMrp())
                .stock(req.getStock())
                .available(true)
                .build();
        vendorProductRepository.save(vp);
    }

    public void updateVendorProduct(Long vpId, Long vendorUserId, com.sparekart.dto.ProductDTOs.VendorAddProductRequest req) {
        VendorProduct vp = vendorProductRepository.findById(vpId)
                .orElseThrow(() -> new RuntimeException("Listing not found"));
        VendorShop shop = vendorShopRepository.findByUserId(vendorUserId)
                .orElseThrow(() -> new RuntimeException("Vendor shop not found"));
        if (!vp.getVendorShop().getId().equals(shop.getId()))
            throw new RuntimeException("Unauthorized");
        vp.setPrice(req.getPrice());
        vp.setMrp(req.getMrp());
        vp.setStock(req.getStock());
        vendorProductRepository.save(vp);
    }
}
