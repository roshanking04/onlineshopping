package com.sparekart.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

// ── CATEGORY ──────────────────────────────────────────────
@Entity
@Table(name = "categories")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
class Category {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false, unique = true, length = 100)
    private String name;
    @Column(nullable = false, length = 10)
    private String icon;
    @Column(nullable = false, unique = true, length = 100)
    private String slug;
    @Column(name = "is_active")
    private boolean active = true;
}

// ── PRODUCT ────────────────────────────────────────────────
@Entity
@Table(name = "products")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
class Product {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(columnDefinition = "JSON")
    private String specifications;

    @Column(name = "image_url", length = 500)
    private String imageUrl;

    @Column(nullable = false, length = 10)
    private String emoji;

    @Column(name = "is_active")
    private boolean active = true;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by", nullable = false)
    private User createdBy;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() { createdAt = LocalDateTime.now(); }
}

// ── VENDOR PRODUCT ─────────────────────────────────────────
@Entity
@Table(name = "vendor_products",
       uniqueConstraints = @UniqueConstraint(columnNames = {"vendor_shop_id","product_id"}))
@Data @NoArgsConstructor @AllArgsConstructor @Builder
class VendorProduct {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vendor_shop_id", nullable = false)
    private VendorShop vendorShop;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal mrp;

    @Column(nullable = false)
    private int stock = 0;

    @Column(name = "is_available", nullable = false)
    private boolean available = true;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() { createdAt = updatedAt = LocalDateTime.now(); }

    @PreUpdate
    protected void onUpdate() { updatedAt = LocalDateTime.now(); }
}
