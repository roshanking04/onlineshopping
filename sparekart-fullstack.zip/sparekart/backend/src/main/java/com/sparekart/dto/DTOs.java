package com.sparekart.dto;

import com.sparekart.model.Order;
import com.sparekart.model.User;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

// ── AUTH ──────────────────────────────────────────────────
public class AuthDTOs {

    @Data public static class RegisterRequest {
        @NotBlank String name;
        @Email @NotBlank String email;
        @NotBlank @Pattern(regexp = "^[6-9]\\d{9}$") String phone;
        @NotBlank @Size(min = 6) String password;
        User.Role role = User.Role.CUSTOMER;
    }

    @Data public static class LoginRequest {
        @NotBlank String email;
        @NotBlank String password;
    }

    @Data @Builder public static class AuthResponse {
        String token;
        Long userId;
        String name;
        String email;
        String phone;
        String role;
    }
}

// ── PRODUCT ───────────────────────────────────────────────
public class ProductDTOs {

    @Data @Builder public static class ProductResponse {
        Long id;
        String name;
        String description;
        String emoji;
        String imageUrl;
        CategoryDTO category;
        List<VendorProductDTO> vendors;
        BigDecimal minPrice;
        int vendorCount;
    }

    @Data @Builder public static class CategoryDTO {
        Integer id;
        String name;
        String icon;
        String slug;
    }

    @Data @Builder public static class VendorProductDTO {
        Long vendorProductId;
        Long vendorShopId;
        String shopName;
        String shopAddress;
        BigDecimal price;
        BigDecimal mrp;
        int stock;
        BigDecimal rating;
        double distanceKm;
        String estimatedDelivery;
    }

    @Data public static class AddProductRequest {
        @NotBlank String name;
        String description;
        @NotNull Integer categoryId;
        @NotBlank String emoji;
        String imageUrl;
        String specifications;
    }

    @Data public static class VendorAddProductRequest {
        @NotNull Long productId;
        @NotNull @DecimalMin("0.01") BigDecimal price;
        @NotNull @DecimalMin("0.01") BigDecimal mrp;
        @Min(0) int stock;
    }
}

// ── VENDOR ────────────────────────────────────────────────
public class VendorDTOs {

    @Data public static class ShopRegisterRequest {
        @NotBlank String shopName;
        @NotBlank String address;
        @NotBlank String city;
        String state = "Maharashtra";
        @NotBlank @Pattern(regexp = "\\d{6}") String pincode;
        @NotNull @DecimalMin("-90.0") @DecimalMax("90.0") BigDecimal latitude;
        @NotNull @DecimalMin("-180.0") @DecimalMax("180.0") BigDecimal longitude;
        String gstin;
    }

    @Data @Builder public static class ShopResponse {
        Long id;
        String shopName;
        String address;
        String city;
        String pincode;
        BigDecimal latitude;
        BigDecimal longitude;
        boolean open;
        BigDecimal rating;
        int totalRatings;
        double distanceKm;
    }
}

// ── ORDER ─────────────────────────────────────────────────
public class OrderDTOs {

    @Data public static class PlaceOrderRequest {
        @NotEmpty List<OrderItemRequest> items;
        @NotNull Long vendorShopId;
        @NotBlank String deliveryAddress;
        BigDecimal deliveryLat;
        BigDecimal deliveryLng;
        String notes;
    }

    @Data public static class OrderItemRequest {
        @NotNull Long vendorProductId;
        @Min(1) int quantity = 1;
    }

    @Data @Builder public static class OrderResponse {
        Long id;
        String orderNumber;
        String status;
        BigDecimal subtotal;
        BigDecimal deliveryFee;
        BigDecimal totalAmount;
        String vendorShopName;
        String vendorPhone;
        String deliveryAddress;
        String otp;
        Integer estimatedMinutes;
        List<OrderItemResponse> items;
        LocalDateTime createdAt;
    }

    @Data @Builder public static class OrderItemResponse {
        Long productId;
        String productName;
        int quantity;
        BigDecimal unitPrice;
        BigDecimal totalPrice;
    }

    @Data public static class UpdateOrderStatusRequest {
        @NotNull Order.OrderStatus status;
        Integer estimatedMinutes;
        String cancelReason;
    }

    @Data public static class VerifyOtpRequest {
        @NotBlank String otp;
    }
}

// ── NOTIFICATION ──────────────────────────────────────────
public class NotificationDTOs {

    @Data @Builder public static class NotificationResponse {
        Long id;
        String title;
        String message;
        String type;
        boolean read;
        Long orderId;
        LocalDateTime createdAt;
    }
}
